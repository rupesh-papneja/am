package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Car;
import com.thrifty.rent.beans.Context;
import com.thrifty.rent.beans.Van;
import com.thrifty.rent.beans.Vehicle;
import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.exception.ValidationException;
import com.thrifty.rent.util.DateTime;
import com.thrifty.rent.util.InputUtils;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class AdditionAction implements Action {
    InputUtils inputUtils = new InputUtils();

    @Override
    public boolean validate(Context c) {
        return true;
    }

    @Override
    public void execute(Context c) {
        try {
            VehicleTypes type = inputVehicleType();
            boolean limit = type == VehicleTypes.VAN ? Context.MAX_LIMIT == c.getVans().size() : Context.MAX_LIMIT == c.getCars().size();
            if (limit) throw new ValidationException("Storage limit reached for vehicle type " + type.toString());
            String vehicleId = inputVehicleId(type);
            if (exists(c, vehicleId)) throw new ValidationException("Vehicle Id already exists.");
            short year = inputYear();
            String make = inputMake();
            String model = inputModel();
            byte numberOfSeats = 15;
            DateTime lastMaintenanceDate = null;
            if (type == VehicleTypes.CAR) {
                numberOfSeats = inputSeats();
            } else {
                lastMaintenanceDate = inputMaintenanceDate();
            }
            if (type == VehicleTypes.VAN) {
                Van v = new Van(vehicleId, year, make, model, StatusTypes.AVAILABLE, lastMaintenanceDate);
                c.getVans().add(v);
            } else {
                Car v = new Car(vehicleId, year, make, model, numberOfSeats, StatusTypes.AVAILABLE);
                c.getCars().add(v);
            }
        } catch (ValidationException e) {
            System.out.printf("\n%s", e.getMessage());
            System.out.println("\nInvalid input provided! returning to main menu.");
            return;
        }
    }

    private DateTime inputMaintenanceDate() throws ValidationException {
        String ds = inputUtils.inputDate("\nEnter the last maintenance date(dd/mm/yyyy): ", true);
        if (ds == null) {
            throw new ValidationException("Error in input for vehicle's last maintenance date.");
        }
        int day = Integer.parseInt(ds.substring(0, 2));
        int month = Integer.parseInt(ds.substring(3, 5));
        int year = Integer.parseInt(ds.substring(6));
        DateTime dt = new DateTime(day, month, year);
        Calendar c = new GregorianCalendar();
        DateTime current = new DateTime(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
        int days = DateTime.diffDays(current, dt);
        if (days < 0) {
            throw new ValidationException("Error in input for vehicle's last maintenance date. Date cannot be greater than current date");
        }
        return dt;
    }

    private byte inputSeats() throws ValidationException {
        String input = inputUtils.input("\nEnter number of seats of the vehicle(4 or 7): ",
                "\nInvalid input", true);
        byte seats = 4;
        if (input == null || input.equals("")) {
            throw new ValidationException("Error in input for vehicle's number of seats");
        }
        try {
            seats = Byte.parseByte(input);
            if (!(seats == 4 || seats == 7)) {
                throw new ValidationException("Error in input for vehicle's number of seats only 4 or 7 allowed.");
            }
        } catch (NumberFormatException e) {
            throw new ValidationException("Error in input for vehicle's number of seats");
        }
        return seats;
    }

    private String inputModel() throws ValidationException {
        String input = inputUtils.input("\nEnter vehicle model: ", "\nInvalid input", true);
        if (input == null || input.equals("")) {
            throw new ValidationException("Error in input for vehicle model");
        }
        return input;
    }

    private String inputMake() throws ValidationException {
        String input = inputUtils.input("\nEnter vehicle make: ", "\nInvalid input", true);
        if (input == null || input.equals("")) {
            throw new ValidationException("Error in input for vehicle make");
        }
        return input;
    }

    private short inputYear() throws ValidationException {
        String input = inputUtils.input("\nEnter year of the vehicle: ",
                "\nInvalid input", true);
        short year = 2019;
        if (input == null || input.equals("")) {
            throw new ValidationException("Error in input for vehicle year");
        }
        try {
            year = Short.parseShort(input);
            if (year < 1900 || year > new GregorianCalendar().get(Calendar.YEAR)) {
                throw new ValidationException("Error in input for vehicle year");
            }
        } catch (NumberFormatException e) {
            throw new ValidationException("Error in input for vehicle year");
        }
        return year;
    }

    private String inputVehicleId(VehicleTypes type) throws ValidationException {
        String input = inputUtils.input("\nEnter vehicle id, starting with C_ for cars and V_ for vans: ",
                "\nInvalid input", true);
        if (input == null || input.equals("")
                || !((type == VehicleTypes.VAN && input.startsWith("V_"))
                || (type == VehicleTypes.CAR && input.startsWith("C_"))
        ) || input.length() < 3
                ) {
            throw new ValidationException("Error in input for vehicle Id");
        }
        return input;
    }

    private VehicleTypes inputVehicleType() throws ValidationException {
        String input = inputUtils.input("\nEnter vehicle type (car, van): ", "\nInvalid input", true);
        if (input == null || input.equals("")
                || !(input.equalsIgnoreCase("van") || input.equalsIgnoreCase("car"))
                ) {
            throw new ValidationException("Error in input for vehicle type");
        }
        return input.equalsIgnoreCase("car") ? VehicleTypes.CAR : VehicleTypes.VAN;
    }

    private boolean exists(Context c, String vehicleId) {
        List<Vehicle> foundCars = c.getCars()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId))
                .collect(Collectors.toList());
        List<Vehicle> foundVans = c.getVans()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId))
                .collect(Collectors.toList());
        if (foundVans.size() + foundCars.size() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
