package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Context;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public interface Action {
    default void execute(Context c) {
        throw new RuntimeException("Implementation not defined!");
    }

    default boolean validate(Context c) {
        if (c.getCars().size() == 0 && c.getVans().size() == 0) {
            return false;
        }
        return true;
    }
}
