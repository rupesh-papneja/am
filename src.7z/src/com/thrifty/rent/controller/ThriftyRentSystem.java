package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Context;

import java.io.Console;
import java.util.Scanner;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class ThriftyRentSystem implements Action {

    @Override
    public void execute(Context c) {
        String message = "\n\n**** ThriftyRent SYSTEM MENU ****\n\n" +
                "Add vehicle:          1\n" +
                "Rent vehicle:         2\n" +
                "Return vehicle:       3\n" +
                "Vehicle Maintenance:  4\n" +
                "Complete Maintenance: 5\n" +
                "Display All Vehicles: 6\n" +
                "Exit Program:         7\n" +
                "\nEnter your choice:    ";
        Console console = System.console();
        String input = "";
        int option = -1;
        do {
            if (console != null) {
                console.printf(message);
                input = console.readLine();
            } else {
                System.out.print(message);
                Scanner scanner = new Scanner(System.in);
                input = scanner.nextLine();
            }
            try {
                option = Integer.parseInt(input.trim());
                processOption(option, c);
            } catch (NumberFormatException | NullPointerException e) {
                System.out.println("\nInvalid option selected, please try again.");
            }
        } while (option != 7);
    }

    private void processOption(int option, Context c) {
        Action action = getAction(option);
        if (action != null) {
            if (action.validate(c)) {
                action.execute(c);
            } else {
                System.out.println("\nValidation failed for the action, No vehicle present!");
            }
        } else {
            System.out.println("\nInvalid option selected, please try again.");
        }
    }

    private Action getAction(int option) {
        switch (option) {
            case 1:
                return new AdditionAction();
            case 2:
                return new RentAction();
            case 3:
                return new ReturnAction();
            case 4:
                return new MaintenanceInitiationAction();
            case 5:
                return new MaintenanceCompletionAction();
            case 6:
                return new DisplayAction();
            case 7:
                return new NOOPAction();
            default:
                return null;
        }
    }

}
