package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Context;
import com.thrifty.rent.beans.RentalRecord;
import com.thrifty.rent.beans.Vehicle;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class DisplayAction implements Action {
    @Override
    public void execute(Context c) {
        c.getCars().forEach(v -> {
            printVehicle(v);
        });
        c.getVans().forEach(v -> {
            printVehicle(v);
        });
    }

    private void printVehicle(Vehicle v) {
        System.out.println(v.getDetails());
        if (v.getRentalRecords().length > 0) {
            System.out.println("\nRENTAL RECORD");
            boolean first = true;
            for (RentalRecord r : v.getRentalRecords()) {
                if (first) {
                    System.out.println("--------------------------------------");
                    first = true;
                }
                System.out.println(r.getDetails());
            }
        } else {
            System.out.println("\nRENTAL RECORD:         empty");
        }
    }
}
