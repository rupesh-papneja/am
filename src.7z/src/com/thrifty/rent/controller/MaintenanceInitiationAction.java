package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Context;
import com.thrifty.rent.beans.Vehicle;
import com.thrifty.rent.util.InputUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class MaintenanceInitiationAction implements Action {
    private InputUtils inputUtils = new InputUtils();

    @Override
    public void execute(Context c) {
        Vehicle v;
        String vehicleId = getVehicleIdInput();
        v = filter(c, vehicleId);
        if (v != null) {
            if (v.performMaintenance() == true)
                System.out.printf("\nVehicle %s is now under maintenance", v.getVehicleId());
            else {
                System.out.printf("\nVehicle %s is not available for maintenance", v.getVehicleId());
            }
        } else {
            System.out.println("\nInvalid input, vehicle id is incorrect.");
        }

    }

    private String getVehicleIdInput() {
        String input = null;
        do {
            input = inputUtils.input("\nEnter vehicle id, starting with C_ for cars and V_ for vans: ",
                    "\nInvalid input", true);
            if (input == null || input.equals("")
                    || !(input.startsWith("V_")
                    || input.startsWith("C_")
            ) || input.length() < 3
                    ) {
                input = null;
                System.out.println("\nInvalid vehicle id. try again");
            }
        } while (input == null);
        return input;
    }

    private Vehicle filter(Context c, String vehicleId) {
        List<Vehicle> foundCars = c.getCars()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId))
                .collect(Collectors.toList());
        List<Vehicle> foundVans = c.getVans()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId))
                .collect(Collectors.toList());
        if (foundVans.size() + foundCars.size() == 1) {
            return foundCars.size() == 1 ? foundCars.get(0) : foundVans.get(0);
        } else {
            return null;
        }
    }
}
