package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Context;
import com.thrifty.rent.beans.Vehicle;
import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.util.DateTime;
import com.thrifty.rent.util.InputUtils;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class RentAction implements Action {

    private InputUtils inputUtils = new InputUtils();

    @Override
    public void execute(Context c) {
        String vehicleId = getVehicleIdInput();
        Vehicle v = filter(c, vehicleId);
        if (v != null) {
            String customerId = getCustomerIdInput();
            DateTime rentDate = getRentDateInput();
            int numberOfDays = getNumOfDaysInput();
            if (v.rent(customerId, rentDate, numberOfDays) == true)
                System.out.printf("\nVehicle %s has been rented successfully", v.getVehicleId());
            else {
                System.out.printf("\nVehicle %s cannot be rented", v.getVehicleId());
            }
        } else {
            System.out.println("\nInvalid input - vehicle id is incorrect.");
        }
    }

    private DateTime getRentDateInput() {
        String ds;
        DateTime dt = null;
        do {
            ds = inputUtils.inputDate("\nEnter the rental start date(dd/mm/yyyy): ", true);
            if (ds == null) {
                System.out.println("\nError in input for rental start date. try again.");
                continue;
            }
            int day = Integer.parseInt(ds.substring(0, 2));
            int month = Integer.parseInt(ds.substring(3, 5));
            int year = Integer.parseInt(ds.substring(6));
            dt = new DateTime(day, month, year);
            Calendar c = new GregorianCalendar();
            DateTime current = new DateTime(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
            int days = DateTime.diffDays(dt, current);
            if (days < 0) {
                System.out.println("\nError in input for rental start date. Date cannot be less than current date.");
                ds = null;
            }
        } while (ds == null);
        return dt;
    }

    private int getNumOfDaysInput() {
        String input;
        int days = -1;
        do {
            input = inputUtils.input("\nEnter number of days for rent: ",
                    "\nInvalid input", true);
            try {
                days = Integer.parseInt(input);
            } catch (NumberFormatException | NullPointerException e) {
                input = null;
            }
        } while (input == null);
        return days;
    }

    private String getCustomerIdInput() {
        String input = null;
        do {
            input = inputUtils.input("\nEnter customer id: ",
                    "\nInvalid input", true);
            if (input == null || input.equals("")) {
                input = null;
                System.out.println("\nInvalid customer id. try again");
            }
        } while (input == null);
        return input;
    }

    private String getVehicleIdInput() {
        String input = null;
        do {
            input = inputUtils.input("\nEnter vehicle id, starting with C_ for cars and V_ for vans: ",
                    "\nInvalid input", true);
            if (input == null || input.equals("")
                    || !(input.startsWith("V_")
                    || input.startsWith("C_")
            ) || input.length() < 3
                    ) {
                input = null;
                System.out.println("\nInvalid vehicle id. try again");
            }
        } while (input == null);
        return input;
    }

    private Vehicle filter(Context c, String vehicleId) {
        List<Vehicle> foundCars = c.getCars()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId)
                                && v.getStatus() == StatusTypes.AVAILABLE
                )
                .collect(Collectors.toList());
        List<Vehicle> foundVans = c.getVans()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId)
                                && v.getStatus() == StatusTypes.AVAILABLE
                )
                .collect(Collectors.toList());
        if (foundVans.size() + foundCars.size() == 1) {
            return foundCars.size() == 1 ? foundCars.get(0) : foundVans.get(0);
        } else {
            return null;
        }
    }
}
