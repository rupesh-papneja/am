package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Context;

/**
 * Created by papnejar on 3/04/2019.
 */
public class NOOPAction implements Action {
    @Override
    public boolean validate(Context c) {
        return true;
    }

    @Override
    public void execute(Context c) {
        return;
    }
}
