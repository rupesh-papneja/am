package com.thrifty.rent.controller;

import com.thrifty.rent.beans.Context;
import com.thrifty.rent.beans.Vehicle;
import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.util.DateTime;
import com.thrifty.rent.util.InputUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class ReturnAction implements Action {

    private InputUtils inputUtils = new InputUtils();

    @Override
    public void execute(Context c) {
        String vehicleId = getVehicleIdInput();
        Vehicle v = filter(c, vehicleId);
        if (v != null) {
            DateTime returnDate = getReturnDateInput();
            if (v.returnVehicle(returnDate) == true)
                System.out.printf("\nVehicle %s has been returned successfully", v.getVehicleId());
            else {
                System.out.printf("\nVehicle %s cannot be returned", v.getVehicleId());
            }
        } else {
            System.out.println("\nInvalid input - vehicle id is incorrect.");
        }
    }

    private DateTime getReturnDateInput() {
        String ds;
        DateTime dt = null;
        do {
            ds = inputUtils.inputDate("\nEnter the renturn date(dd/mm/yyyy): ", true);
            if (ds == null) {
                System.out.println("\nError in input for return date. try again.");
                continue;
            }
            int day = Integer.parseInt(ds.substring(0, 2));
            int month = Integer.parseInt(ds.substring(3, 5));
            int year = Integer.parseInt(ds.substring(6));
            dt = new DateTime(day, month, year);
        } while (ds == null);
        return dt;
    }

    private String getVehicleIdInput() {
        String input;
        do {
            input = inputUtils.input("\nEnter vehicle id, starting with C_ for cars and V_ for vans: ",
                    "\nInvalid input", true);
            if (input == null || input.equals("")
                    || !(input.startsWith("V_")
                    || input.startsWith("C_")
            ) || input.length() < 3
                    ) {
                input = null;
                System.out.println("\nInvalid vehicle id. try again");
            }
        } while (input == null);
        return input;
    }

    private Vehicle filter(Context c, String vehicleId) {
        List<Vehicle> foundCars = c.getCars()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId)
                                && v.getStatus() == StatusTypes.RENTED
                )
                .collect(Collectors.toList());
        List<Vehicle> foundVans = c.getVans()
                .stream()
                .filter(v -> v.getVehicleId().equalsIgnoreCase(vehicleId)
                                && v.getStatus() == StatusTypes.RENTED
                )
                .collect(Collectors.toList());
        if (foundVans.size() + foundCars.size() == 1) {
            return foundCars.size() == 1 ? foundCars.get(0) : foundVans.get(0);
        } else {
            return null;
        }
    }
}
