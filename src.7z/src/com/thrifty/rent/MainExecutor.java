package com.thrifty.rent;

import com.thrifty.rent.beans.Context;
import com.thrifty.rent.controller.ThriftyRentSystem;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class MainExecutor {
    public static void main(String [] args) {
        new ThriftyRentSystem().execute(new Context());
    }
}
