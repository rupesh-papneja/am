package com.thrifty.rent.beans;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.util.DateTime;
import com.thrifty.rent.util.Queue;

import java.util.ArrayList;
import java.util.List;

/**
 * Domain class representing Vehicle
 * @author Priya Narayan Dhingra
 * @version 1.0
 */
public abstract class Vehicle {
    private String vehicleId;
    private short year;
    private String make;
    private String model;
    private byte numOfSeats;
    private VehicleTypes type;
    private StatusTypes status;
    private DateTime lastMaintenanceDate;

    @Override
    public String toString() {
        return vehicleId + ':' + year + ':' + make + ':' + model + ':' + numOfSeats + ':' + status;
    }

    protected Vehicle(String vehicleId, short year, String make, String model, byte numOfSeats, VehicleTypes type, StatusTypes status, DateTime lastMaintenanceDate) {
        this.vehicleId = vehicleId;
        this.year = year;
        this.make = make;
        this.model = model;
        this.numOfSeats = numOfSeats;
        this.type = type;
        this.status = status;
        this.lastMaintenanceDate = lastMaintenanceDate;
        this.rentalRecords = new Queue<>(10);
    }

    private Queue<RentalRecord> rentalRecords;

    /**
     * Return the vehicle vehicleId
     * @return String vehicleId
     */
    public String getVehicleId() {
        return vehicleId;
    }

    public VehicleTypes getType() {
        return type;
    }

    public StatusTypes getStatus() {
        return status;
    }

    protected void setStatus(StatusTypes status) {
        this.status = status;
    }

    protected DateTime getLastMaintenanceDate() {
        return lastMaintenanceDate;
    }

    protected byte getNumOfSeats() {
        return numOfSeats;
    }

    public RentalRecord[] getRentalRecords() {
        List<RentalRecord> records = rentalRecords.peek();
        return records.toArray(new RentalRecord[records.size()]);
    }

    protected RentalRecord getRentalRecord() {
        return rentalRecords.peekFirst();
    }

    protected void setRentalRecord(RentalRecord rentalRecord) {
        rentalRecords.enqueue(rentalRecord);
    }

    public String getDetails() {
        StringBuilder builder = new StringBuilder();
        builder.append("\nVehicle ID:            ");
        builder.append(vehicleId);
        builder.append("\nYear:                  ");
        builder.append(year);
        builder.append("\nMake:                  ");
        builder.append(make);
        builder.append("\nNumber of seats:       ");
        builder.append(numOfSeats);
        builder.append("\nStatus:                ");
        builder.append(status.toString());
        if (lastMaintenanceDate != null) {
            builder.append("\nLast maintenance date: ");
            builder.append(lastMaintenanceDate.toString());
        }
        return builder.toString();
    }

    public abstract boolean rent(String customerId, DateTime rentDate, int numOfRentDay);
    public abstract boolean returnVehicle(DateTime returnDate);
    public boolean performMaintenance() {
        if (status == StatusTypes.AVAILABLE) {
            status = StatusTypes.MAINTENANCE;
            return true;
        }
        return false;
    }
    public boolean completeMaintenance(DateTime completionDate) {
        if (status == StatusTypes.MAINTENANCE) {
            lastMaintenanceDate = completionDate;
            status = StatusTypes.AVAILABLE;
            return true;
        }
        return false;
    }

    protected String [] validateReturn(DateTime returnDate) {
        List<String> errors = new ArrayList<>();
        if(getStatus() != StatusTypes.RENTED) {
            errors.add("\nVehicle is not Rented.");
        }
        RentalRecord record = getRentalRecord();
        if(DateTime.diffDays(returnDate, record.getRentDate()) < 0) {
            errors.add("\nThe return date cannot be less than rental start date.");
        }
        return errors.toArray(new String[errors.size()]);
    }
}
