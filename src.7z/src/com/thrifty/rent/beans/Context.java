package com.thrifty.rent.beans;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class Context {
    private List<Car> cars = new ArrayList<>();
    private List<Van> vans = new ArrayList<>();
    public static int MAX_LIMIT = 50;

    public List<Car> getCars() {
        return cars;
    }

    public List<Van> getVans() {
        return vans;
    }
}
