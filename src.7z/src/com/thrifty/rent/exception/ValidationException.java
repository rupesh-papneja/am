package com.thrifty.rent.exception;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }
}
