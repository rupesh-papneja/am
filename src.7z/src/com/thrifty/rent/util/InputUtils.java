package com.thrifty.rent.util;

import java.io.Console;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Priya Dhingra on 3/04/2019.
 */
public class InputUtils {

    private Console console = System.console();
    private Scanner scanner = new Scanner(System.in);

    private String regex = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$";
    private Pattern pattern = Pattern.compile(regex);

    public String input(String msg, String error, boolean exitOnInvalid) {
        String s;
        do {
            if (null != console) {
                System.out.print(msg);
                s = console.readLine();
            } else {
                System.out.print(msg);
                s = scanner.nextLine();
            }
            if (s == null || s.trim().equals("")) {
                System.out.println(error);
                if (exitOnInvalid) break;
            }
        } while(s == null || s.trim().equals(""));
        return processInput(s);
    }

    public String inputDate(String msg, boolean exitOnInvalid) {
        String s;
        boolean matches;
        do {
            if (null != console) {
                System.out.print(msg);
                s = console.readLine();
            } else {
                System.out.print(msg);
                s = scanner.nextLine();
            }
            s = processInput(s);
            Matcher matcher = pattern.matcher(s);
            matches = matcher.matches();
            if (s == null || s.trim().equals("") || !matches) {
                if (exitOnInvalid) break;
            }
        } while(s == null || s.equals("") || !matches);
        return s;
    }

    private String processInput(String s) {
        if (null != s) {
            return s.trim();
        }
        return s;
    }
}
