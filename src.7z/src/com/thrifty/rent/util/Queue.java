package com.thrifty.rent.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Priya Dhingra on 31/03/2019.
 */
public class Queue<T> {
    List<T> records;
    int size;

    public Queue(int size) {
        this.size = size;
        records = new ArrayList<T>();
    }

    public void enqueue(T record) {
        List<T> tempRecords = new ArrayList<T>();
        if (records.size() == size) {
            tempRecords.add(record);
            tempRecords.addAll(records.subList(0, size - 2));
        } else {
            tempRecords.add(record);
            tempRecords.addAll(records);
        }
        this.records = tempRecords;
    }

    public List<T> peek() {
        return records;
    }

    public T peekFirst() {
        return records.get(0);
    }
}
