package com.thrifty.rent.controller.detail;

import com.thrifty.rent.controller.ApplicationContext;
import com.thrifty.rent.database.RentalRecord;
import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.model.Vehicle;
import com.thrifty.rent.view.detail.RentalRecordView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static com.thrifty.rent.controller.ApplicationContext.defaultImage;

public class ProcessController implements Initializable {
    @FXML
    private GridPane grid;

    @FXML
    private TableView tableView;

    @FXML
    private Button backButton;

    @FXML
    private HBox detailsBox;

    private RentalRecord rdb = new RentalRecord();
    private Vehicle vehicle;
    private com.thrifty.rent.database.Vehicle vdb = new com.thrifty.rent.database.Vehicle();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox.setVgrow(grid, Priority.ALWAYS);
        detailsBox.setSpacing(40);
        detailsBox.setHgrow(new Region(), Priority.ALWAYS);
        detailsBox.setAlignment(Pos.CENTER);
        detailsBox.setPadding(new Insets(0, 20, 10, 20));
        ImageView imageView = new ImageView();
        imageView.setFitHeight(32);
        imageView.setFitWidth(32);
        imageView.setImage(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/back.png")));
        backButton.setGraphic(imageView);
        backButton.setPadding(Insets.EMPTY);
        backButton.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                backButton.fire();
        });
        VBox vbox = new VBox();
        try {
            this.vehicle = vdb.fetchById(ApplicationContext.getSelectedVehicle());
            vbox.getChildren().add(initializeControls(vehicle));
            tableView.getItems().removeAll();
            for (com.thrifty.rent.model.RentalRecord rentalRecord :
                    rdb.fetchAll(ApplicationContext.getSelectedVehicle())) {
                tableView.getItems().add(new RentalRecordView(rentalRecord));
            }
            ImageView iv = new ImageView();
            if (vehicle.getImageFile().equalsIgnoreCase(defaultImage)) {
                iv.setImage(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/na.jpg"),
                                450, 300, false, false));
            } else {
                File f = new File(vehicle.getImageFile());
                if (f.exists() && f.isFile()) {
                    iv.setImage(new Image(f.toURI().toString(), 300, 200, false, false));
                }
            }
            Region region = new Region();
            HBox.setHgrow(region, Priority.ALWAYS);
            detailsBox.getChildren().add(region);
            detailsBox.getChildren().add(iv);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
        vbox.getChildren().add(setupButtons());
        Region region = new Region();
        HBox.setHgrow(region, Priority.ALWAYS);
        detailsBox.getChildren().add(region);
        detailsBox.getChildren().add(vbox);
    }

    private void setIcons(Button button, String icon) {
        ImageView imageView = new ImageView();
        imageView.setFitHeight(64);
        imageView.setFitWidth(64);
        imageView.setImage(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/" + icon)));
        button.setGraphic(imageView);
        button.setPadding(Insets.EMPTY);
        button.setId(icon.replaceFirst(".png", ""));
        button.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                button.fire();
        });
        button.setDisable(true);
        button.setOnAction(actionEvent -> {
            String id = ((Button)actionEvent.getSource()).getId();
            switch (id) {
                case "return":
                    break;
                case "rent":
                    break;
                case "maintenance":
                    break;
                case "complete":
                    break;
            }
        });
    }

    private HBox setupButtons(){
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.setPadding(new Insets(30, 10, 10, 10));
        hbox.setSpacing(20);
        Button rent = new Button();
        setIcons(rent, "rent.png");
        Button returnButton = new Button();
        setIcons(returnButton, "return.png");
        Button maintenance = new Button();
        setIcons(maintenance, "maintenance.png");
        Button complete = new Button();
        setIcons(complete, "complete.png");
        if(this.vehicle.getStatus() == StatusTypes.AVAILABLE) {
            rent.setDisable(false);
            maintenance.setDisable(false);
        } else if(this.vehicle.getStatus() == StatusTypes.MAINTENANCE) {
            complete.setDisable(false);
        } else if(this.vehicle.getStatus() == StatusTypes.RENTED){
            returnButton.setDisable(false);
        }
        hbox.getChildren().addAll(rent, returnButton, maintenance, complete);
        return hbox;
    }

    public void back(ActionEvent actionEvent) {
        loadMain();
        closeStage();
    }

    private GridPane initializeControls(Vehicle vehicle) {
        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(12);
        ColumnConstraints left = new ColumnConstraints();
        left.setHalignment(HPos.LEFT);
        pane.getColumnConstraints().add(left);
        ColumnConstraints right = new ColumnConstraints();
        right.setHalignment(HPos.RIGHT);
        pane.getColumnConstraints().add(right);

        Label labelVehicleType = new Label("Vehicle Type");
        pane.add(labelVehicleType, 0, 0);
        pane.add(new Label(vehicle.getType().toString()), 1, 0);

        Label labelVehicleId = new Label("Vehicle Id");
        pane.add(labelVehicleId, 0, 1);
        pane.add(new Label(vehicle.getVehicleId()), 1, 1);

        Label labelYear = new Label("Year");
        pane.add(labelYear, 0, 2);
        pane.add(new Label(String.valueOf(vehicle.getYear())), 1, 2);

        Label labelMake = new Label("Make");
        pane.add(labelMake, 0, 3);
        pane.add(new Label(vehicle.getMake()), 1, 3);

        Label labelModel = new Label("Model");
        pane.add(labelModel, 0, 4);
        pane.add(new Label(vehicle.getModel()), 1, 4);

        Label labelSeats = new Label("Number of Seats");
        pane.add(labelSeats, 0, 5);
        pane.add(new Label(String.valueOf(vehicle.getNumOfSeats())), 1, 5);

        Label labelStatus = new Label("Status");
        pane.add(labelStatus, 0, 6);
        pane.add(new Label(vehicle.getStatus().toString()), 1, 6);

        if (null != vehicle.getLastMaintenanceDate()) {
            Label labelLastMaintenanceDate = new Label("Last Maintenance Date (dd/mm/yyyy)     ");
            pane.add(labelLastMaintenanceDate, 0, 7);
            pane.add(new Label(vehicle.getLastMaintenanceDate().getFormattedDate()), 1, 7);
        }
        return pane;
    }

    private void loadMain() {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource("/com/thrifty/rent/view/main/main.fxml"));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Thrifty Rental System");
            stage.setScene(new Scene(parent));
            stage.show();
            Screen screen = Screen.getPrimary();
            Rectangle2D bounds = screen.getVisualBounds();

            stage.setX(bounds.getMinX());
            stage.setY(bounds.getMinY());
            stage.setWidth(bounds.getWidth());
            stage.setHeight(bounds.getHeight());

            stage.getIcons().add(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/icon.png")));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private void closeStage() {
        ((Stage) backButton.getScene().getWindow()).close();
    }
}
