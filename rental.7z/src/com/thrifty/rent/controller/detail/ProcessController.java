package com.thrifty.rent.controller.detail;

import com.thrifty.rent.controller.ApplicationContext;
import com.thrifty.rent.database.RentalRecord;
import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.exception.ApplicationException;
import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.model.RentSelectionModel;
import com.thrifty.rent.model.Vehicle;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.util.DateTime;
import com.thrifty.rent.view.detail.CompleteMaintenance;
import com.thrifty.rent.view.detail.Rent;
import com.thrifty.rent.view.detail.RentalRecordView;
import com.thrifty.rent.view.detail.RentalReturn;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import static com.thrifty.rent.controller.ApplicationContext.defaultImage;

public class ProcessController implements Initializable {

    @FXML
    public Label records;

    @FXML
    private GridPane grid;

    @FXML
    private TableView tableView;

    @FXML
    private Button backButton;

    @FXML
    private HBox detailsBox;

    private RentalRecord rdb = new RentalRecord();
    private Vehicle vehicle;
    private com.thrifty.rent.database.Vehicle vdb = new com.thrifty.rent.database.Vehicle();
    private Button rent;
    private Button returnButton;
    private Button maintenance;
    private Button complete;
    private Label status;
    private Label maintenanceDateValue;
    private com.thrifty.rent.model.RentalRecord latestRentalRecord;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox.setVgrow(grid, Priority.ALWAYS);
        detailsBox.setSpacing(40);
        detailsBox.setHgrow(new Region(), Priority.ALWAYS);
        detailsBox.setAlignment(Pos.CENTER);
        detailsBox.setPadding(new Insets(0, 20, 10, 20));
        ImageView imageView = new ImageView();
        imageView.setFitHeight(32);
        imageView.setFitWidth(32);
        imageView.setImage(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/back.png")));
        backButton.setGraphic(imageView);
        backButton.setPadding(Insets.EMPTY);
        backButton.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                backButton.fire();
        });
        VBox vbox = new VBox();
        try {
            this.vehicle = vdb.fetchById(ApplicationContext.getSelectedVehicle());
            vbox.getChildren().add(initializeControls(vehicle));
            updateRentalRecords();
            ImageView iv = new ImageView();
            if (vehicle.getImageFile().equalsIgnoreCase(defaultImage)) {
                iv.setImage(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/na.jpg"),
                        450, 300, false, false));
            } else {
                File f = new File(vehicle.getImageFile());
                if (f.exists() && f.isFile()) {
                    iv.setImage(new Image(f.toURI().toString(), 300, 200, false, false));
                }
            }
            Region region = new Region();
            HBox.setHgrow(region, Priority.ALWAYS);
            detailsBox.getChildren().add(region);
            detailsBox.getChildren().add(iv);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
        vbox.getChildren().add(setupButtons());
        Region region = new Region();
        HBox.setHgrow(region, Priority.ALWAYS);
        detailsBox.getChildren().add(region);
        detailsBox.getChildren().add(vbox);
    }

    private void updateRentalRecords() throws DatabaseException {
        tableView.getItems().removeAll(tableView.getItems());
        latestRentalRecord = null;
        for (com.thrifty.rent.model.RentalRecord rentalRecord :
                rdb.fetchAll(ApplicationContext.getSelectedVehicle())) {
            if (null == latestRentalRecord) {
                latestRentalRecord = rentalRecord;
            }
            tableView.getItems().add(new RentalRecordView(rentalRecord));
        }
        records.setText("Total Rental records: " + tableView.getItems().size());
    }

    private void setIcons(Button button, String icon) {
        ImageView imageView = new ImageView();
        imageView.setFitHeight(64);
        imageView.setFitWidth(64);
        imageView.setImage(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/" + icon)));
        button.setGraphic(imageView);
        button.setPadding(Insets.EMPTY);
        button.setId(icon.replaceFirst(".png", ""));
        button.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                button.fire();
        });
        button.setDisable(true);
        button.setOnAction(actionEvent -> {
            String id = ((Button) actionEvent.getSource()).getId();
            switch (id) {
                case "return":
                    handleReturn();
                    break;
                case "rent":
                    handleRent();
                    break;
                case "maintenance":
                    handleMaintenance();
                    break;
                case "complete":
                    handleCompleteMaintenance();
                    break;
            }
        });
    }

    private void handleRent() {
        Rent rent = new Rent(new Callback() {
            @Override
            public void execute(Serializable input) throws CallExecutionException {
                RentSelectionModel model = (RentSelectionModel) input;
                try {
                    com.thrifty.rent.model.RentalRecord record = vehicle.rent(model.getCustomerId(), new DateTime(model.getRentStartDate()),
                            model.getNumberOfDays());
                    record.setVehicleId(vehicle.getVehicleId());
                    rdb.insert(record);
                    vdb.updateStatus(vehicle.getVehicleId(), vehicle.getStatus());
                    updateRentalRecords();
                    enableButtons();
                    handleAlert("Vehicle rented successfully.", Alert.AlertType.INFORMATION);
                } catch (ApplicationException e) {
                    handleAlert("Error while processing rent request: " + e.getMessage(), Alert.AlertType.ERROR);
                    throw new CallExecutionException(e.getMessage());
                }
            }
        });
        rent.getOptionalResult().ifPresent((file) -> {
            // control is returned here after task is closed
        });
    }

    private void handleReturn() {
        if (null != latestRentalRecord) {
            RentalReturn rentalReturn = new RentalReturn(new Callback() {
                @Override
                public void execute(Serializable input) throws CallExecutionException {
                    try {
                        LocalDate dt = (LocalDate) input;
                        vehicle.returnVehicle(new DateTime(dt), latestRentalRecord);
                        rdb.update(latestRentalRecord);
                        vdb.updateStatus(vehicle.getVehicleId(), StatusTypes.AVAILABLE);
                        updateRentalRecords();
                        enableButtons();
                        handleAlert("Vehicle returned. The vehicle is now available.", Alert.AlertType.INFORMATION);
                    } catch (ApplicationException e) {
                        handleAlert("Error while processing return request: " + e.getMessage(), Alert.AlertType.ERROR);
                        throw new CallExecutionException(e.getMessage());
                    }
                }
            }, latestRentalRecord.getRentDate());
            rentalReturn.getOptionalResult().ifPresent((file) -> {
                // control is returned here after task is closed
            });
        }
    }

    private void handleCompleteMaintenance() {
        if (vehicle.getType() == VehicleTypes.VAN) {
            CompleteMaintenance completeMaintenance = new CompleteMaintenance(new Callback() {
                @Override
                public void execute(Serializable input) throws CallExecutionException {
                    try {
                        LocalDate dt = (LocalDate) input;
                        vdb.updateStatusAndMaintenanceDate(vehicle.getVehicleId(), StatusTypes.AVAILABLE, dt);
                        vehicle.completeMaintenance(new DateTime(dt));
                        maintenanceDateValue.setText(vehicle.getLastMaintenanceDate().getFormattedDate());
                        enableButtons();
                        handleAlert("Maintenance complete. The vehicle is now available.", Alert.AlertType.INFORMATION);
                    } catch (ApplicationException e) {
                        handleAlert("Error while processing maintenance request: " + e.getMessage(), Alert.AlertType.ERROR);
                        throw new CallExecutionException(e.getMessage());
                    }
                }
            }, vehicle.getLastMaintenanceDate());
            completeMaintenance.getOptionalResult().ifPresent((file) -> {
                // control is returned here after task is closed
            });
        } else {
            try {
                LocalDate dt = LocalDate.now();
                vdb.updateStatusAndMaintenanceDate(vehicle.getVehicleId(), StatusTypes.AVAILABLE, dt);
                vehicle.completeMaintenance(new DateTime(dt));
                handleAlert("Maintenance complete. The vehicle is now available.", Alert.AlertType.INFORMATION);
                enableButtons();
            } catch (ApplicationException e) {
                handleAlert("Error while processing maintenance request: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    private void handleMaintenance() {
        try {
            vehicle.performMaintenance();
            vdb.updateStatus(vehicle.getVehicleId(), StatusTypes.MAINTENANCE);
            enableButtons();
            handleAlert("The vehicle is under maintenance.", Alert.AlertType.INFORMATION);
        } catch (ApplicationException e) {
            handleAlert("Error while processing maintenance request: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void handleAlert(String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.initStyle(StageStyle.UNDECORATED);
        alert.setTitle(null);
        alert.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        alert.setHeaderText(null);
        alert.setGraphic(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private HBox setupButtons() {
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.setPadding(new Insets(30, 10, 10, 10));
        hbox.setSpacing(20);
        rent = new Button();
        setIcons(rent, "rent.png");
        returnButton = new Button();
        setIcons(returnButton, "return.png");
        maintenance = new Button();
        setIcons(maintenance, "maintenance.png");
        complete = new Button();
        setIcons(complete, "complete.png");
        enableButtons();
        hbox.getChildren().addAll(rent, returnButton, maintenance, complete);
        return hbox;
    }

    private void enableButtons() {
        rent.setDisable(true);
        maintenance.setDisable(true);
        complete.setDisable(true);
        returnButton.setDisable(true);
        if (this.vehicle.getStatus() == StatusTypes.AVAILABLE) {
            rent.setDisable(false);
            maintenance.setDisable(false);
        } else if (this.vehicle.getStatus() == StatusTypes.MAINTENANCE) {
            complete.setDisable(false);
        } else if (this.vehicle.getStatus() == StatusTypes.RENTED) {
            returnButton.setDisable(false);
        }
        status.setText(this.vehicle.getStatus().toString());
    }

    public void back(ActionEvent actionEvent) {
        loadMain();
        closeStage();
    }

    private GridPane initializeControls(Vehicle vehicle) {
        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(12);
        ColumnConstraints left = new ColumnConstraints();
        left.setHalignment(HPos.LEFT);
        pane.getColumnConstraints().add(left);
        ColumnConstraints right = new ColumnConstraints();
        right.setHalignment(HPos.RIGHT);
        pane.getColumnConstraints().add(right);

        Label labelVehicleType = new Label("Vehicle Type");
        pane.add(labelVehicleType, 0, 0);
        pane.add(new Label(vehicle.getType().toString()), 1, 0);

        Label labelVehicleId = new Label("Vehicle Id");
        pane.add(labelVehicleId, 0, 1);
        pane.add(new Label(vehicle.getVehicleId()), 1, 1);

        Label labelYear = new Label("Year");
        pane.add(labelYear, 0, 2);
        pane.add(new Label(String.valueOf(vehicle.getYear())), 1, 2);

        Label labelMake = new Label("Make");
        pane.add(labelMake, 0, 3);
        pane.add(new Label(vehicle.getMake()), 1, 3);

        Label labelModel = new Label("Model");
        pane.add(labelModel, 0, 4);
        pane.add(new Label(vehicle.getModel()), 1, 4);

        Label labelSeats = new Label("Number of Seats");
        pane.add(labelSeats, 0, 5);
        pane.add(new Label(String.valueOf(vehicle.getNumOfSeats())), 1, 5);

        Label labelStatus = new Label("Status");
        pane.add(labelStatus, 0, 6);
        status = new Label(vehicle.getStatus().toString());
        pane.add(status, 1, 6);

        if (null != vehicle.getLastMaintenanceDate()) {
            Label labelLastMaintenanceDate = new Label("Last Maintenance Date (dd/mm/yyyy)     ");
            pane.add(labelLastMaintenanceDate, 0, 7);
            maintenanceDateValue = new Label(vehicle.getLastMaintenanceDate().getFormattedDate());
            pane.add(maintenanceDateValue, 1, 7);
        }
        return pane;
    }

    private void loadMain() {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource("/com/thrifty/rent/view/main/main.fxml"));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Thrifty Rental System");
            stage.setScene(new Scene(parent));
            stage.show();
            Screen screen = Screen.getPrimary();
            Rectangle2D bounds = screen.getVisualBounds();

            stage.setX(bounds.getMinX());
            stage.setY(bounds.getMinY());
            stage.setWidth(bounds.getWidth());
            stage.setHeight(bounds.getHeight());

            stage.getIcons().add(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/icon.png")));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private void closeStage() {
        ((Stage) backButton.getScene().getWindow()).close();
    }
}
