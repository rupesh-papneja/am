package com.thrifty.rent.controller.main;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.model.Vehicle;
import com.thrifty.rent.view.main.VehicleView;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import static com.thrifty.rent.controller.ApplicationContext.*;

public class VehicleController implements Initializable {

    @FXML
    GridPane grid;

    @FXML
    TableView tableView;

    @FXML
    ComboBox<String> cType;

    @FXML
    ComboBox<Byte> cSeats;

    @FXML
    ComboBox<String> cStatus;

    @FXML
    ComboBox<String> cMake;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox.setVgrow(grid, Priority.ALWAYS);
        setList(tableView.getItems());
        setMakes(cMake.getItems());
        setController(this);
        cType.getItems().addAll("CAR", "VAN");
        cSeats.getItems().addAll((byte) 4, (byte) 7, (byte) 15);
        cStatus.getItems().addAll(
                StatusTypes.AVAILABLE.toString(),
                StatusTypes.RENTED.toString(),
                StatusTypes.MAINTENANCE.toString());
        try {
            tableView.getItems().removeAll();
            com.thrifty.rent.database.Vehicle vdb = new com.thrifty.rent.database.Vehicle();
            List<Vehicle> vehicles = vdb.fetchAll();
            setVehicles(vehicles);
            for (Vehicle v : vehicles) {
                tableView.getItems().add(new VehicleView(v));
            }
            List<String> makes = vdb.fetchAllMakes();
            cMake.getItems().addAll(makes);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
    }

    public void filterOnType(ActionEvent actionEvent) throws DatabaseException {
        filter();
    }

    public void filterOnSeats(ActionEvent actionEvent) throws DatabaseException {
        filter();
    }

    public void filterOnStatus(ActionEvent actionEvent) throws DatabaseException {
        filter();
    }

    public void filterOnMake(ActionEvent actionEvent) throws DatabaseException {
        filter();
    }

    public void clearFilters(ActionEvent actionEvent) {
        cType.getSelectionModel().clearSelection();
        cSeats.getSelectionModel().clearSelection();
        cMake.getSelectionModel().clearSelection();
        cStatus.getSelectionModel().clearSelection();
        setFilterOn(false);
        getList().removeAll(tableView.getItems());
        getVehicles().forEach(v -> getList().add(new VehicleView(v)));
    }

    private void filter() throws DatabaseException {
        String t = cType.getSelectionModel().getSelectedItem();
        final String m = cMake.getSelectionModel().getSelectedItem();
        final Byte s = cSeats.getSelectionModel().getSelectedItem();
        final String st = cStatus.getSelectionModel().getSelectedItem();
        final VehicleTypes vt = t == null ? null : VehicleTypes.valueOf(t);
        final StatusTypes vst = st == null ? null : StatusTypes.valueOf(st);
        if (st != null || s != null || m != null || t != null) {
            com.thrifty.rent.database.Vehicle vdb = new com.thrifty.rent.database.Vehicle();
            List<Vehicle> filtered = vdb.filter(vt, m, vst, s);
            setFilterOn(true);
            getList().removeAll(tableView.getItems());
            filtered.forEach(v -> getList().add(new VehicleView(v)));
        }
    }
}
