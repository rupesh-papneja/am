package com.thrifty.rent.controller.main;

import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.model.Vehicle;
import com.thrifty.rent.view.main.VehiclesView;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import static com.thrifty.rent.controller.ApplicationContext.setList;

public class VehicleController implements Initializable {

    @FXML
    VBox vbox;

    @FXML
    GridPane grid;

    @FXML
    TableView tableView;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox.setVgrow(grid, Priority.ALWAYS);
        setList(tableView.getItems());
        try {
            List<Vehicle> vehicles = new com.thrifty.rent.database.Vehicle().fetchAll();
            for (Vehicle v : vehicles) {
                tableView.getItems().add(new VehiclesView(v));
            }
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
    }
}
