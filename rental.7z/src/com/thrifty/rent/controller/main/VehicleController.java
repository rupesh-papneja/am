package com.thrifty.rent.controller.main;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.ResourceBundle;

public class VehicleController implements Initializable {

    @FXML
    VBox vbox;

    @FXML
    GridPane grid;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox.setVgrow(grid, Priority.ALWAYS);
    }
}
