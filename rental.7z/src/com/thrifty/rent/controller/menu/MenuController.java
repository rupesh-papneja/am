package com.thrifty.rent.controller.menu;


import com.thrifty.rent.view.menu.ExportDialog;
import com.thrifty.rent.view.menu.ImportDialog;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.StageStyle;

public class MenuController {

    @FXML
    void keyPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            Object s = event.getSource();
            if (s instanceof Button) {
                Button button = (Button) s;
                button.fire();
            }
        }
    }

    public void handleExit(ActionEvent actionEvent) {
        System.exit(0);
    }

    public void handleExport(ActionEvent actionEvent) {
        ExportDialog exportDialog = new ExportDialog();
        exportDialog.getOptionalResult().ifPresent((String directory)-> {
            System.out.println(directory);
        });
    }

    public void handleImport(ActionEvent actionEvent) {
        ImportDialog importDialog = new ImportDialog();
        importDialog.getOptionalResult().ifPresent((String file)-> {
            System.out.println(file);
        });
    }

    public void handleAbout(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UNDECORATED);
        alert.setTitle(null);
        alert.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        alert.setHeaderText(null);
        alert.setGraphic(null);
        alert.setContentText("Thrifty Vehicle Rental System, version 1.0.1");
        alert.showAndWait();
    }

    public void handleAddition(ActionEvent actionEvent) {

    }
}
