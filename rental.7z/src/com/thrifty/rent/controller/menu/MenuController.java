package com.thrifty.rent.controller.menu;


import com.thrifty.rent.database.RentalRecord;
import com.thrifty.rent.database.Vehicle;
import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.view.main.VehicleView;
import com.thrifty.rent.view.menu.Export;
import com.thrifty.rent.view.menu.Import;
import com.thrifty.rent.view.menu.NewVehicle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static com.thrifty.rent.controller.ApplicationContext.*;

public class MenuController {

    @FXML
    void keyPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            Object s = event.getSource();
            if (s instanceof Button) {
                Button button = (Button) s;
                button.fire();
            }
        }
    }

    public void handleExit(ActionEvent actionEvent) {
        System.exit(0);
    }

    public void handleExport(ActionEvent actionEvent) {
        Export export = new Export(new Callback() {
            @Override
            public void execute(Serializable input) throws CallExecutionException {
                String fileName = ((String) input) + File.separator + "export_data.txt";
                StringBuilder builder = new StringBuilder();
                Vehicle vdb = new Vehicle();
                RentalRecord rdb = new RentalRecord();
                try {
                    List<com.thrifty.rent.model.Vehicle> vehicles = vdb.fetchAll();
                    for (com.thrifty.rent.model.Vehicle v : vehicles) {
                        builder.append(v.toString());
                        builder.append(System.lineSeparator());
                        rdb.fetchAll(v.getVehicleId()).forEach(r -> {
                            builder.append(r.toString());
                            builder.append(System.lineSeparator());
                        });
                    }
                    Files.write(Paths.get(fileName), builder.toString().trim().getBytes());
                    handleAlert("Data exported successfully at " + fileName, Alert.AlertType.INFORMATION);
                } catch (DatabaseException | IOException e) {
                    handleAlert("Error while processing the request: " + e.getMessage(), Alert.AlertType.ERROR);
                    throw new CallExecutionException(e);
                }
            }
        });
        export.getOptionalResult().ifPresent((directory) -> {
            // control is returned here after task is closed
        });
    }

    private void handleAlert(String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.initStyle(StageStyle.UNDECORATED);
        alert.setTitle(null);
        alert.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        alert.setHeaderText(null);
        alert.setGraphic(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void handleImport(ActionEvent actionEvent) {
        Import importView = new Import(new Callback() {
            @Override
            public void execute(Serializable input) throws CallExecutionException {
                String fileName = ((String) input);
                File file = new File(fileName);
                if(file.exists() && file.isFile() && file.canRead()) {
                    try {
                        for (String line : Files.readAllLines(file.toPath())) {

                        }
                    } catch (IOException e) {
                        handleAlert("Error while processing the request: " + e.getMessage(), Alert.AlertType.ERROR);
                        throw new CallExecutionException(e);
                    }
                    handleAlert("Data imported successfully from " + fileName, Alert.AlertType.INFORMATION);
                } else {
                    handleAlert("Error while reading the file " + fileName , Alert.AlertType.ERROR);
                    throw new CallExecutionException("Error in reading file");
                }
            }
        });
        importView.getOptionalResult().ifPresent((file) -> {
            // control is returned here after task is closed
        });
    }

    public void handleAbout(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UNDECORATED);
        alert.setTitle(null);
        alert.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        alert.setHeaderText(null);
        alert.setGraphic(null);
        alert.setContentText("Thrifty Vehicle Rental System, version 1.0.1");
        alert.showAndWait();
    }

    public void handleAddition(ActionEvent actionEvent) {
        NewVehicle newVehicle = new NewVehicle(new Callback() {
            @Override
            public void execute(Serializable input) throws CallExecutionException {
                try {
                    Vehicle v = new Vehicle();
                    com.thrifty.rent.model.Vehicle model = (com.thrifty.rent.model.Vehicle) input;
                    v.checkNotExistsById(model.getVehicleId());
                    v.create(model);
                    getVehicles().add(model);
                    if (isFilterOn()) {
                        controller().clearFilters(null);
                    } else getList().add(new VehicleView(model));
                    if (!getMakes().contains(model.getMake()))
                        getMakes().add(model.getMake());
                    controller().setRecords(getList().size());
                } catch (DatabaseException e) {
                    throw new CallExecutionException(e.getMessage());
                }
            }
        });
        newVehicle.getOptionalResult().ifPresent((Boolean status) -> {
            // control is returned here after task is closed
        });
    }
}
