package com.thrifty.rent.controller.menu;


import com.thrifty.rent.view.menu.Export;
import com.thrifty.rent.view.menu.Import;
import com.thrifty.rent.view.menu.NewVehicle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.StageStyle;

public class MenuController {

    @FXML
    void keyPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            Object s = event.getSource();
            if (s instanceof Button) {
                Button button = (Button) s;
                button.fire();
            }
        }
    }

    public void handleExit(ActionEvent actionEvent) {
        System.exit(0);
    }

    public void handleExport(ActionEvent actionEvent) {
        Export export = new Export();
        export.getOptionalResult().ifPresent((String directory) -> {
            System.out.println(directory);
        });
    }

    public void handleImport(ActionEvent actionEvent) {
        Import importView = new Import();
        importView.getOptionalResult().ifPresent((String file) -> {
            System.out.println(file);
        });
    }

    public void handleAbout(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UNDECORATED);
        alert.setTitle(null);
        alert.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        alert.setHeaderText(null);
        alert.setGraphic(null);
        alert.setContentText("Thrifty Vehicle Rental System, version 1.0.1");
        alert.showAndWait();
    }

    public void handleAddition(ActionEvent actionEvent) {
        NewVehicle newVehicle = new NewVehicle();
        newVehicle.getOptionalResult().ifPresent((Boolean status) -> {
            System.out.println("Vehicle addition " + status);
        });
    }
}
