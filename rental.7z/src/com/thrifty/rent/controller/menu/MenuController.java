package com.thrifty.rent.controller.menu;


import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.stage.StageStyle;

public class MenuController {


    public void handleExit(ActionEvent actionEvent) {
        System.exit(0);
    }

    public void handleExport(ActionEvent actionEvent) {

    }

    public void handleImport(ActionEvent actionEvent) {

    }

    public void handleAbout(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UNDECORATED);
        alert.setTitle(null);
        alert.getDialogPane().setStyle("-fx-base: rgba(80, 80, 84, 255)");
        alert.setHeaderText(null);
        alert.setGraphic(null);
        alert.setContentText("Thrifty rental system, version 1.0.1");
        alert.showAndWait();
    }

    public void handleAddition(ActionEvent actionEvent) {

    }
}
