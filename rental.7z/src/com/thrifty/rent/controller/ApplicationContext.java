package com.thrifty.rent.controller;

import com.thrifty.rent.controller.main.VehicleListController;
import com.thrifty.rent.model.Vehicle;
import com.thrifty.rent.view.main.VehicleView;
import javafx.collections.ObservableList;

import java.util.List;

public final class ApplicationContext {
    public static int imageWidth = 100;
    public static int imageHeight = 75;
    public static String defaultImage = "NA";
    private static ObservableList<VehicleView> list;
    private static ObservableList<String> makes;
    private static List<Vehicle> vehicles;
    private static boolean filterOn;
    private static VehicleListController vehicleListController;
    private static String selectedVehicle;

    private ApplicationContext() {
    }

    public static VehicleListController controller() {
        return vehicleListController;
    }

    public static ObservableList<String> getMakes() {
        return makes;
    }

    public static void setMakes(ObservableList<String> makes) {
        ApplicationContext.makes = makes;
    }


    public static ObservableList<VehicleView> getList() {
        return list;
    }

    public static void setList(ObservableList<VehicleView> list) {
        ApplicationContext.list = list;
    }

    public static List<Vehicle> getVehicles() {
        return vehicles;
    }

    public static void setVehicles(List<Vehicle> vehicles) {
        ApplicationContext.vehicles = vehicles;
    }

    public static boolean isFilterOn() {
        return filterOn;
    }

    public static void setFilterOn(boolean filterOn) {
        ApplicationContext.filterOn = filterOn;
    }

    public static void setController(VehicleListController vehicleListController) {
        ApplicationContext.vehicleListController = vehicleListController;
    }

    public static String getSelectedVehicle() {
        return selectedVehicle;
    }

    public static void setSelectedVehicle(String selectedVehicle) {
        ApplicationContext.selectedVehicle = selectedVehicle;
    }
}
