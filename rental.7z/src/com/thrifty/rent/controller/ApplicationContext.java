package com.thrifty.rent.controller;

import com.thrifty.rent.view.main.VehiclesView;
import javafx.collections.ObservableList;

public final class ApplicationContext {
    public static int imageWidth = 100;
    public static int imageHeight = 75;
    public static String defaultImage = "NA";
    private static ObservableList<VehiclesView> list;

    private ApplicationContext() {
    }

    public static ObservableList<VehiclesView> getList() {
        return list;
    }

    public static void setList(ObservableList list) {
        ApplicationContext.list = list;
    }
}
