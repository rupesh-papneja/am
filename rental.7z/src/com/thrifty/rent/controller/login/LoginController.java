package com.thrifty.rent.controller.login;

import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class LoginController implements Initializable {

    private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");
    @FXML
    private TextField textUser;

    @FXML
    private PasswordField textPassword;

    @FXML
    private Label message;

    @FXML
    void keyPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            Object s = event.getSource();
            if (s instanceof Button) {
                Button button = (Button) s;
                button.fire();
            }
        }
    }

    public void loginAction(ActionEvent event) {
        message.setText("");
        textUser.pseudoClassStateChanged(errorClass, false);
        textPassword.pseudoClassStateChanged(errorClass, false);
        String email = textUser.getText().toString();
        String password = textPassword.getText().toString();
        if (null == email || email.trim().length() == 0) {
            message.setText("Please enter user name.");
            textUser.pseudoClassStateChanged(errorClass, true);
            return;
        }
        if (null == password || password.trim().length() == 0) {
            message.setText("Please enter password.");
            textPassword.pseudoClassStateChanged(errorClass, true);
            return;
        }
        if (!"root".equals(password) || !"root".equals(password)) {
            message.setText("Invalid user name or password.");
            textUser.pseudoClassStateChanged(errorClass, true);
            textPassword.pseudoClassStateChanged(errorClass, true);
            return;
        }
        closeStage();
        loadMain();
    }

    private void loadMain() {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource("/com/thrifty/rent/view/main/main.fxml"));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Thrifty Rental System");
            stage.setScene(new Scene(parent));
            stage.show();
            Screen screen = Screen.getPrimary();
            Rectangle2D bounds = screen.getVisualBounds();

            stage.setX(bounds.getMinX());
            stage.setY(bounds.getMinY());
            stage.setWidth(bounds.getWidth());
            stage.setHeight(bounds.getHeight());

            stage.getIcons().add(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/icon.png")));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private void closeStage() {
        ((Stage) textUser.getScene().getWindow()).close();
    }

    public void cancelAction(ActionEvent event) {
        System.exit(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        message.setStyle("-fx-font-weight: bold; -fx-text-fill: rgba(9, 172, 242, 255);");
        Platform.runLater(this::setProperty);
    }

    private void setProperty() {
        textUser.getScene().focusOwnerProperty().addListener(
                (prop, oldNode, newNode) -> {
                    message.setText("");
                    textUser.pseudoClassStateChanged(errorClass, false);
                    textPassword.pseudoClassStateChanged(errorClass, false);
                }
        );
    }
}
