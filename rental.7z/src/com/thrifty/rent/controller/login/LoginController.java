package com.thrifty.rent.controller.login;

import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.view.login.Login;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.io.Serializable;


public class LoginController {

    private final Login login;

    public LoginController() {
        login = new Login(new Callback() {
            @Override
            public void execute(Serializable input) throws CallExecutionException {
                closeStage();
                loadMain();
            }
        });
    }

    private void loadMain() {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource("/com/thrifty/rent/view/main/main.fxml"));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Thrifty Rental System");
            stage.setScene(new Scene(parent));
            stage.show();
            Screen screen = Screen.getPrimary();
            Rectangle2D bounds = screen.getVisualBounds();

            stage.setX(bounds.getMinX());
            stage.setY(bounds.getMinY());
            stage.setWidth(bounds.getWidth());
            stage.setHeight(bounds.getHeight());

            stage.getIcons().add(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/icon.png")));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private void closeStage() {
        login.close();
    }

    public void cancelAction(ActionEvent event) {
        System.exit(0);
    }

}
