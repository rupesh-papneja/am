package com.thrifty.rent.main;

import com.thrifty.rent.controller.login.LoginController;
import com.thrifty.rent.database.DatabaseConnection;
import com.thrifty.rent.view.login.Login;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        DatabaseConnection.instance().setup();
        new LoginController();

    }
}
