package com.thrifty.rent.task;

import com.thrifty.rent.exception.CallExecutionException;

import java.io.Serializable;

public interface Callback {
    default void execute(Serializable input) throws CallExecutionException {
        throw new CallExecutionException("Implementation not defined!");
    }
}
