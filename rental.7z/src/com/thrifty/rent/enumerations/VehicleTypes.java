package com.thrifty.rent.enumerations;

/**
 * Created by Priya Dhingra on 30/03/2019.
 */
public enum VehicleTypes {
    CAR("Car"),
    VAN("Van");

    private String value;

    VehicleTypes(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
