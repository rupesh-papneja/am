package com.thrifty.rent.enumerations;

/**
 * Created by Priya Dhingra on 30/03/2019.
 */
public enum StatusTypes {
    AVAILABLE("AVAILABLE"),
    RENTED("RENTED"),
    MAINTENANCE("MAINTENANCE");

    private String value;

    StatusTypes(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
