package com.thrifty.rent.view;

import com.thrifty.rent.task.Callback;
import javafx.scene.control.Dialog;

import java.util.Optional;

public abstract class TaskDialog extends Dialog<Boolean> {
    protected Optional<Boolean> optionalResult;
    protected Callback c;

    protected TaskDialog(Callback c) {
        this.c = c;
    }

    public Optional<Boolean> getOptionalResult() {
        return optionalResult;
    }
}
