package com.thrifty.rent.view.main;

import com.thrifty.rent.controller.ApplicationContext;
import com.thrifty.rent.model.Vehicle;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;

import static com.thrifty.rent.controller.ApplicationContext.imageHeight;
import static com.thrifty.rent.controller.ApplicationContext.imageWidth;

public class VehiclesView {
    private final Vehicle vehicle;

    public SimpleStringProperty vehicleId = new SimpleStringProperty();
    public ObjectProperty imageFile = new SimpleObjectProperty();
    public SimpleIntegerProperty year = new SimpleIntegerProperty();
    public SimpleStringProperty make = new SimpleStringProperty();
    public SimpleStringProperty model = new SimpleStringProperty();
    public SimpleIntegerProperty numOfSeats = new SimpleIntegerProperty();
    public SimpleStringProperty type = new SimpleStringProperty();
    public SimpleStringProperty status = new SimpleStringProperty();
    public SimpleStringProperty lastMaintenanceDate = new SimpleStringProperty();

    public VehiclesView(Vehicle vehicle) {
        this.vehicle = vehicle;
        ImageView imageView = new ImageView();
        if (vehicle.getImageFile().equalsIgnoreCase(ApplicationContext.defaultImage)) {
            imageView.setImage(new Image(
                    getClass().getResourceAsStream("/com/thrifty/rent/view/resources/na.jpg"),
                    imageWidth, imageHeight, false, false)
            );
        } else {
            File file = new File(vehicle.getImageFile());
            if (file.exists() && file.isFile()) {
                imageView.setImage(new Image(
                        file.toURI().toString(), imageWidth, imageHeight, false, false)
                );

            }
        }

        imageFile.setValue(imageView);
        vehicleId.set(vehicle.getVehicleId());
        year.set(vehicle.getYear());
        make.set(vehicle.getMake());
        model.set(vehicle.getModel());
        numOfSeats.set(vehicle.getNumOfSeats());
        type.set(vehicle.getType().name());
        status.set(vehicle.getStatus().name());
        if (null != vehicle.getLastMaintenanceDate()) {
            lastMaintenanceDate.set(vehicle.getLastMaintenanceDate().getFormattedDate());
        }
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public String getVehicleId() {
        return vehicleId.get();
    }

    public SimpleStringProperty vehicleIdProperty() {
        return vehicleId;
    }

    public Object getImageFile() {
        return imageFile.get();
    }

    public ObjectProperty imageFileProperty() {
        return imageFile;
    }

    public int getYear() {
        return year.get();
    }

    public SimpleIntegerProperty yearProperty() {
        return year;
    }

    public String getMake() {
        return make.get();
    }

    public SimpleStringProperty makeProperty() {
        return make;
    }

    public String getModel() {
        return model.get();
    }

    public SimpleStringProperty modelProperty() {
        return model;
    }

    public int getNumOfSeats() {
        return numOfSeats.get();
    }

    public SimpleIntegerProperty numOfSeatsProperty() {
        return numOfSeats;
    }

    public String getType() {
        return type.get();
    }

    public SimpleStringProperty typeProperty() {
        return type;
    }

    public String getStatus() {
        return status.get();
    }

    public SimpleStringProperty statusProperty() {
        return status;
    }

    public String getLastMaintenanceDate() {
        return lastMaintenanceDate.get();
    }

    public SimpleStringProperty lastMaintenanceDateProperty() {
        return lastMaintenanceDate;
    }
}
