package com.thrifty.rent.view.main;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.model.Vehicle;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

import java.io.File;
import java.io.Serializable;

import static com.thrifty.rent.controller.ApplicationContext.*;

public class VehicleView {
    private final Vehicle vehicle;

    public SimpleStringProperty vehicleId = new SimpleStringProperty();
    public ObjectProperty imageFile = new SimpleObjectProperty();
    public SimpleIntegerProperty year = new SimpleIntegerProperty();
    public SimpleStringProperty make = new SimpleStringProperty();
    public SimpleStringProperty model = new SimpleStringProperty();
    public ObjectProperty numOfSeats = new SimpleObjectProperty();
    public SimpleStringProperty type = new SimpleStringProperty();
    public ObjectProperty status = new SimpleObjectProperty();
    public SimpleStringProperty lastMaintenanceDate = new SimpleStringProperty();

    public VehicleView(Vehicle vehicle) {
        this.vehicle = vehicle;
        imageFile.setValue(getImageObject(vehicle.getImageFile()));
        vehicleId.set(vehicle.getVehicleId());
        year.set(vehicle.getYear());
        make.set(vehicle.getMake());
        model.set(vehicle.getModel());
        numOfSeats.set(getSeatsObject(vehicle.getNumOfSeats()));
        type.set(vehicle.getType().name());
        status.set(getStatusObject(vehicle.getStatus()));
        if (null != vehicle.getLastMaintenanceDate()) {
            lastMaintenanceDate.set(vehicle.getLastMaintenanceDate().getFormattedDate());
        }
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public String getVehicleId() {
        return vehicleId.get();
    }

    public SimpleStringProperty vehicleIdProperty() {
        return vehicleId;
    }

    public Object getImageFile() {
        return imageFile.get();
    }

    public ObjectProperty imageFileProperty() {
        return imageFile;
    }

    public int getYear() {
        return year.get();
    }

    public SimpleIntegerProperty yearProperty() {
        return year;
    }

    public String getMake() {
        return make.get();
    }

    public SimpleStringProperty makeProperty() {
        return make;
    }

    public String getModel() {
        return model.get();
    }

    public SimpleStringProperty modelProperty() {
        return model;
    }

    public Object getNumOfSeats() {
        return numOfSeats.get();
    }

    public ObjectProperty numOfSeatsProperty() {
        return numOfSeats;
    }

    public String getType() {
        return type.get();
    }

    public SimpleStringProperty typeProperty() {
        return type;
    }

    public Object getStatus() {
        return status.get();
    }

    public ObjectProperty statusProperty() {
        return status;
    }

    public String getLastMaintenanceDate() {
        return lastMaintenanceDate.get();
    }

    public SimpleStringProperty lastMaintenanceDateProperty() {
        return lastMaintenanceDate;
    }

    private HBox getStatusObject(StatusTypes status) {
        String image = "/com/thrifty/rent/view/resources/process_green.png";
        if (status == StatusTypes.RENTED) {
            image = "/com/thrifty/rent/view/resources/process_rent.png";
        } else if (status == StatusTypes.MAINTENANCE) {
            image = "/com/thrifty/rent/view/resources/process_maintenance.png";
        }
        HBox box = new HBox();
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        ImageView imageView = new ImageView();
        imageView.setFitHeight(32);
        imageView.setFitWidth(32);
        imageView.setImage(
                new Image(
                        getClass().getResourceAsStream(image)
                )
        );
        Button button = new Button();
        button.setGraphic(imageView);
        button.setPadding(Insets.EMPTY);
        button.setOnAction(actionEvent -> {
            // call detail window
        });
        box.getChildren().add(0, new Label(String.valueOf(status)));
        box.getChildren().add(1, button);
        return box;
    }

    private HBox getImageObject(String file) {

        ImageView imageView = new ImageView();
        if (file.equalsIgnoreCase(defaultImage)) {
            imageView.setImage(new Image(
                            getClass().getResourceAsStream("/com/thrifty/rent/view/resources/na.jpg"),
                            imageWidth, imageHeight, false, false)
            );
        } else {
            File f = new File(file);
            if (f.exists() && f.isFile()) {
                imageView.setImage(new Image(
                                f.toURI().toString(), imageWidth, imageHeight, false, false)
                );

            }
        }
        HBox box = new HBox();
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        Button button = new Button();
        button.setOnAction(actionEvent -> {
            new VehicleImage(new com.thrifty.rent.task.Callback() {
                @Override
                public void execute(Serializable input) throws CallExecutionException {
                    ImageView iv = new ImageView();
                    if (file.equalsIgnoreCase(defaultImage)) {
                        iv.setImage(
                                new Image(
                                        getClass().getResourceAsStream("/com/thrifty/rent/view/resources/na.jpg"),
                                        512, 400, false, false
                                )
                        );
                    } else {
                        File f = new File(file);
                        if (f.exists() && f.isFile()) {
                            iv.setImage(new Image(
                                            f.toURI().toString(),
                                            512, 400, false, false)
                            );
                        }
                    }
                    ((VehicleImage) input).getBox().getChildren().add(new ImageView(iv.getImage()));
                }
            });
        });
        button.setGraphic(imageView);
        button.setPadding(Insets.EMPTY);
        box.getChildren().add(button);
        return box;
    }

    private HBox getSeatsObject(byte seats) {
        HBox box = new HBox();
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        ImageView imageView = new ImageView();
        imageView.setFitHeight(32);
        imageView.setFitWidth(32);
        imageView.setImage(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/seat.png")));

        box.getChildren().addAll(imageView, new Label(String.valueOf(seats)));
        return box;
    }
}
