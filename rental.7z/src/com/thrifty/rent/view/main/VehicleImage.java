package com.thrifty.rent.view.main;

import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.view.TaskDialog;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.Serializable;

public class VehicleImage extends TaskDialog implements Serializable {
    private VBox box;

    public VehicleImage(Callback c) {
        super(c);
        box = new VBox();
        box.setAlignment(Pos.CENTER);
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK);
        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText(null);
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        this.setResultConverter((ButtonType button) -> (button == ButtonType.OK) ? true : null);
        Platform.runLater(this::execute);
        this.getDialogPane().setContent(box);
        this.optionalResult = this.showAndWait();
    }

    public VBox getBox() {
        return box;
    }

    private void execute() {
        try {
            this.c.execute(this);
            getDialogPane().requestLayout();
            Stage stage = (Stage) getDialogPane().getScene().getWindow();
            stage.sizeToScene();
            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
            stage.setX((screenBounds.getWidth() - stage.getWidth()) / 2);
            stage.setY((screenBounds.getHeight() - stage.getHeight()) / 2);
        } catch (CallExecutionException e) {

        }
    }
}
