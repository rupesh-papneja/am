package com.thrifty.rent.view.detail;

import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.model.RentSelectionModel;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.view.TaskDialog;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.StageStyle;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Rent extends TaskDialog {
    private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");
    private Rent self;
    private com.thrifty.rent.view.control.TextField customerId = new com.thrifty.rent.view.control.TextField(50);
    private Label message = new Label("");
    private com.thrifty.rent.view.control.TextField numberOfDays = new com.thrifty.rent.view.control.TextField(2);
    private DatePicker rentDate = new DatePicker();

    private String regex = "^[0-9]{1,}$";
    private Pattern pattern = Pattern.compile(regex);

    public Rent(Callback c) {
        super(c);
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setText("Save");
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setDefaultButton(false);
        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText("Rent Vehicle");
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        message.setStyle("-fx-font-weight: bold; -fx-text-fill: rgba(9, 172, 242, 255);");
        self = this;
        this.initialize();
    }

    private void reset() {
        message.setVisible(false);
        message.setText("");
        customerId.pseudoClassStateChanged(errorClass, false);
        numberOfDays.pseudoClassStateChanged(errorClass, false);
        rentDate.pseudoClassStateChanged(errorClass, false);
    }

    private void setupOKButton() {
        self.getDialogPane().lookupButton(ButtonType.OK).addEventFilter(ActionEvent.ACTION,
                event -> {
                    reset();
                    List<String> errors = validate();
                    // Check whether some conditions are fulfilled
                    if (errors.size() > 0) {
                        // The conditions are not fulfilled so we consume the event
                        // to prevent the dialog to close
                        message.setVisible(true);
                        message.setText("Invalid " + String.join(", ", errors));
                        event.consume();
                    } else {
                        try {
                            c.execute(new RentSelectionModel(customerId.getText(),
                                    Integer.parseInt(numberOfDays.getText()), rentDate.getValue()));
                        } catch (CallExecutionException e) {
                            //message.setVisible(true);
                            //message.setText(e.getMessage());
                            event.consume();
                        }
                    }
                }
        );
    }

    private List<String> validate() {
        List<String> errors = new ArrayList<>();
        if (null == customerId.getText() || "".equals(customerId.getText().trim())) {
            customerId.pseudoClassStateChanged(errorClass, true);
            errors.add("Customer Id");
        }
        if (null == numberOfDays.getText() || "".equals(numberOfDays.getText().trim())) {
            numberOfDays.pseudoClassStateChanged(errorClass, true);
            errors.add("Number of Days");
        } else if (null != numberOfDays.getText()) {
            Matcher matcher = pattern.matcher(numberOfDays.getText());
            if (!matcher.matches()) {
                numberOfDays.pseudoClassStateChanged(errorClass, true);
                errors.add("Number of Days");
            } else {
                int days = Integer.parseInt(numberOfDays.getText());
                if (days <= 0) {
                    numberOfDays.pseudoClassStateChanged(errorClass, true);
                    errors.add("Number of Days");
                }
            }
        }
        if (null == rentDate.getValue()
                || rentDate.getValue().isBefore(LocalDate.now())) {
            rentDate.pseudoClassStateChanged(errorClass, true);
            errors.add("Rental Start Date");
        }
        return errors;
    }

    private void initialize() {
        initializeRentalStartDate();
        this.getDialogPane().setContent(new VBox(12, initializeControls(), message));
        this.getDialogPane().lookupButton(ButtonType.OK).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.OK)).fire();
        });
        this.getDialogPane().lookupButton(ButtonType.CANCEL).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.CANCEL)).fire();
        });
        this.getDialogPane().getScene().focusOwnerProperty().addListener(
                (prop, oldNode, newNode) -> self.reset());
        setupOKButton();
        Platform.runLater(customerId::requestFocus);
        message.setVisible(false);
        this.setResultConverter((ButtonType button) -> (button == ButtonType.OK) ? true : null);
        this.optionalResult = this.showAndWait();
    }

    private void initializeRentalStartDate() {
        rentDate.setConverter(new StringConverter<LocalDate>() {
            String pattern = "dd/MM/yyyy";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

            {
                rentDate.setPromptText(pattern.toLowerCase());
            }

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });
        LocalDate minDate = LocalDate.now();
        LocalDate maxDate = LocalDate.now().plusMonths(12);
        rentDate.setDayCellFactory(d -> new DateCell() {
            @Override
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                setDisable(item.isAfter(maxDate) || item.isBefore(minDate));
            }
        });
    }

    private GridPane initializeControls() {
        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(12);
        ColumnConstraints left = new ColumnConstraints();
        left.setHalignment(HPos.LEFT);
        pane.getColumnConstraints().add(left);
        ColumnConstraints right = new ColumnConstraints();
        right.setHalignment(HPos.RIGHT);
        pane.getColumnConstraints().add(right);

        Label labelCustomerId = new Label("Customer Id");
        pane.add(labelCustomerId, 0, 1);
        pane.add(customerId, 1, 1);

        Label labelNumberOfSeats = new Label("Number of Days");
        pane.add(labelNumberOfSeats, 0, 2);
        pane.add(numberOfDays, 1, 2);

        Label labelRentDate = new Label("Rental Start Date (dd/mm/yyyy)     ");
        pane.add(labelRentDate, 0, 3);
        pane.add(rentDate, 1, 3);

        return pane;
    }
}
