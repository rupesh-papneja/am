package com.thrifty.rent.view.detail;

import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.util.DateTime;
import com.thrifty.rent.view.TaskDialog;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class CompleteMaintenance extends TaskDialog {

    private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");
    private final PseudoClass messageClass = PseudoClass.getPseudoClass("message");
    private CompleteMaintenance self;
    private Label message = new Label("");
    private DateTime lastMaintenanceDate;
    private DatePicker completionDate = new DatePicker();

    public CompleteMaintenance(Callback c, DateTime lastMaintenanceDate) {
        super(c);
        this.lastMaintenanceDate = lastMaintenanceDate;
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setDefaultButton(false);
        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText("Maintenance completion date");
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        self = this;
        message.pseudoClassStateChanged(messageClass, true);
        initializeCompletionDate();
        setupOKButton();
        HBox hbox = new HBox();
        hbox.setSpacing(2.0);
        hbox.getChildren().add(completionDate);
        this.getDialogPane().setContent(new VBox(12, message, hbox));
        this.getDialogPane().lookupButton(ButtonType.OK).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.OK)).fire();
        });
        this.getDialogPane().lookupButton(ButtonType.CANCEL).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.CANCEL)).fire();
        });
        this.getDialogPane().getScene().focusOwnerProperty().addListener(
                (prop, oldNode, newNode) -> self.reset());
        Platform.runLater(completionDate::requestFocus);
        this.setResultConverter((ButtonType button) -> (button == ButtonType.OK) ? true : null);
        optionalResult = this.showAndWait();
    }

    private void setupOKButton() {
        self.getDialogPane().lookupButton(ButtonType.OK).addEventFilter(ActionEvent.ACTION,
                event -> {
                    reset();
                    if (null == completionDate.getValue()
                            || completionDate.getValue().isAfter(LocalDate.now())) {
                        completionDate.pseudoClassStateChanged(errorClass, true);
                        message.setText("Please select completion date.");
                        self.getDialogPane().requestLayout();
                        Stage stage = (Stage) self.getDialogPane().getScene().getWindow();
                        stage.sizeToScene();
                        event.consume();
                    } else {
                        try {
                            c.execute(completionDate.getValue());
                        } catch (CallExecutionException e) {
                            //message.setText(e.getMessage());
                            event.consume();
                        }
                    }
                }
        );
    }

    private void initializeCompletionDate() {
        completionDate.setConverter(new StringConverter<LocalDate>() {
            String pattern = "dd/MM/yyyy";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

            {
                completionDate.setPromptText(pattern.toLowerCase());
            }

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });
        Calendar c = new GregorianCalendar();
        final LocalDate minDate = null != lastMaintenanceDate ?
                lastMaintenanceDate.getLocalDate() :
                LocalDate.of(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, 1);

        final LocalDate maxDate = LocalDate.now();
        completionDate.setDayCellFactory(d -> new DateCell() {
            @Override
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                setDisable(item.isAfter(maxDate) || item.isBefore(minDate));
            }
        });
    }

    private void reset() {
        message.setText("");
        completionDate.pseudoClassStateChanged(errorClass, false);
    }
}
