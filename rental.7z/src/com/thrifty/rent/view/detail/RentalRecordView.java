package com.thrifty.rent.view.detail;

import com.thrifty.rent.model.RentalRecord;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

public class RentalRecordView {
    private final RentalRecord record;
    public SimpleStringProperty recordId = new SimpleStringProperty();
    public SimpleStringProperty rentDate = new SimpleStringProperty();
    public SimpleStringProperty estimatedReturnDate = new SimpleStringProperty();
    public SimpleStringProperty actualReturnDate = new SimpleStringProperty();
    public SimpleStringProperty vehicleId = new SimpleStringProperty();
    public SimpleDoubleProperty rentalFee = new SimpleDoubleProperty();
    public SimpleDoubleProperty lateFee = new SimpleDoubleProperty();


    public RentalRecordView(RentalRecord record) {
        this.record = record;
        recordId.set(record.getRecordId());
        rentDate.set(record.getRentDate().getFormattedDate());
        estimatedReturnDate.set(record.getEstimatedReturnDate().getFormattedDate());
        vehicleId.set(record.getVehicleId());
        if (null != record.getActualReturnDate()) {
            actualReturnDate.set(record.getActualReturnDate().getFormattedDate());
        }
        rentalFee.set(record.getRentalFee());
        lateFee.set(record.getLateFee());
    }

    public String getRecordId() {
        return recordId.get();
    }

    public SimpleStringProperty recordIdProperty() {
        return recordId;
    }

    public String getRentDate() {
        return rentDate.get();
    }

    public SimpleStringProperty rentDateProperty() {
        return rentDate;
    }

    public String getEstimatedReturnDate() {
        return estimatedReturnDate.get();
    }

    public SimpleStringProperty estimatedReturnDateProperty() {
        return estimatedReturnDate;
    }

    public String getActualReturnDate() {
        return actualReturnDate.get();
    }

    public SimpleStringProperty actualReturnDateProperty() {
        return actualReturnDate;
    }

    public String getVehicleId() {
        return vehicleId.get();
    }

    public SimpleStringProperty vehicleIdProperty() {
        return vehicleId;
    }

    public double getRentalFee() {
        return rentalFee.get();
    }

    public SimpleDoubleProperty rentalFeeProperty() {
        return rentalFee;
    }

    public double getLateFee() {
        return lateFee.get();
    }

    public SimpleDoubleProperty lateFeeProperty() {
        return lateFee;
    }
}
