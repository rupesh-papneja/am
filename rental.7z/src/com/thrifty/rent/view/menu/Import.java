package com.thrifty.rent.view.menu;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.StageStyle;

import java.io.File;
import java.util.Optional;

public class Import extends Dialog<String> {

    private final FileChooser fileChooser = new FileChooser();
    private Optional<String> optionalResult;
    private Import self;


    public Import() {
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        this.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setDefaultButton(false);
        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText(null);
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        Label label = new Label("Select the file to import data ");
        self = this;
        HBox hbox = new HBox();
        hbox.setSpacing(2.0);
        TextField textField = new TextField();
        Button fileButton = new Button("...");
        fileButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                self.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
                File file = fileChooser.showOpenDialog(self.getDialogPane().getScene().getWindow());
                if (file != null) {
                    textField.setText(file.getAbsolutePath());
                    self.getDialogPane().lookupButton(ButtonType.OK).setDisable(false);
                } else textField.setText(null);
            }
        });
        textField.setEditable(false);
        textField.setFocusTraversable(false);
        hbox.getChildren().add(textField);
        hbox.getChildren().add(fileButton);
        this.getDialogPane().setContent(new VBox(12, label, hbox));
        fileButton.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                fileButton.fire();
        });
        this.getDialogPane().lookupButton(ButtonType.OK).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.OK)).fire();
        });
        this.getDialogPane().lookupButton(ButtonType.CANCEL).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.CANCEL)).fire();
        });
        Platform.runLater(fileButton::requestFocus);
        this.setResultConverter((ButtonType button) -> (button == ButtonType.OK) ? textField.getText() : null);
        optionalResult = this.showAndWait();
    }

    public Optional<String> getOptionalResult() {
        return optionalResult;
    }

}
