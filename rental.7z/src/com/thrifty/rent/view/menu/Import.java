package com.thrifty.rent.view.menu;

import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.view.TaskDialog;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.StageStyle;

import java.io.File;

public class Import extends TaskDialog {

    private final FileChooser fileChooser = new FileChooser();
    private final PseudoClass messageClass = PseudoClass.getPseudoClass("message");
    private Import self;
    private Label message = new Label("");
    private TextField textField = new TextField();

    public Import(Callback c) {
        super(c);
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        this.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setDefaultButton(false);
        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText("Import Data");
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        // Label label = new Label("Select the file to import data ");
        self = this;
        message.setVisible(false);
        message.pseudoClassStateChanged(messageClass, true);
        setupOKButton();
        HBox hbox = new HBox();
        hbox.setSpacing(2.0);
        Button fileButton = new Button("...");
        fileButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                self.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
                File file = fileChooser.showOpenDialog(self.getDialogPane().getScene().getWindow());
                if (file != null) {
                    textField.setText(file.getAbsolutePath());
                    self.getDialogPane().lookupButton(ButtonType.OK).setDisable(false);
                } else textField.setText(null);
            }
        });
        textField.setEditable(false);
        textField.setFocusTraversable(false);
        hbox.getChildren().add(textField);
        hbox.getChildren().add(fileButton);
        this.getDialogPane().setContent(new VBox(12, message, hbox));
        fileButton.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                fileButton.fire();
        });
        this.getDialogPane().lookupButton(ButtonType.OK).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.OK)).fire();
        });
        this.getDialogPane().lookupButton(ButtonType.CANCEL).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.CANCEL)).fire();
        });
        Platform.runLater(fileButton::requestFocus);
        this.setResultConverter((ButtonType button) -> (button == ButtonType.OK) ? true : null);
        optionalResult = this.showAndWait();
    }

    private void setupOKButton() {
        self.getDialogPane().lookupButton(ButtonType.OK).addEventFilter(ActionEvent.ACTION,
                event -> {
                    message.setVisible(false);
                    message.setText("");
                    try {
                        c.execute(textField.getText());
                    } catch (CallExecutionException e) {
                        message.setVisible(true);
                        message.setText(e.getMessage());
                        event.consume();
                    }
                }
        );
    }
}
