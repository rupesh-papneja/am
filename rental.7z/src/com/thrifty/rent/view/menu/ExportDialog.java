package com.thrifty.rent.view.menu;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.StageStyle;

import java.io.File;
import java.util.Optional;

public class ExportDialog extends Dialog<String> {

    private final DirectoryChooser directoryChooser = new DirectoryChooser();
    private Optional<String> optionalResult;
    private ExportDialog self;



    public Optional<String> getOptionalResult() {
        return optionalResult;
    }

    public ExportDialog() {
        directoryChooser.setTitle("Select directory for export");
        directoryChooser.setInitialDirectory(new File(System.getProperty("user.home")));
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        this.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);

        ((Button)this.getDialogPane().lookupButton(ButtonType.OK)).setDefaultButton(false);

        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText(null);
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        Label label = new Label("Select the folder to export data ");
        self = this;
        HBox hbox = new HBox();
        hbox.setSpacing(2.0);

        TextField textField = new TextField();
        Button directoryButton = new Button("...");

        directoryButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                self.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
                File dir = directoryChooser.showDialog(null);
                if (dir != null) {
                    textField.setText(dir.getAbsolutePath());
                    self.getDialogPane().lookupButton(ButtonType.OK).setDisable(false);
                } else {
                    textField.setText(null);
                }
            }
        });
        textField.setEditable(false);
        textField.setFocusTraversable(false);

        hbox.getChildren().add(textField);
        hbox.getChildren().add(directoryButton);

        this.getDialogPane().setContent(new VBox(12, label, hbox));

        directoryButton.setOnKeyPressed(
                event -> {
                    if(((KeyEvent)event).getCode() == KeyCode.ENTER){
                        directoryButton.fire();
                    }
                });

        this.getDialogPane().lookupButton(ButtonType.OK).setOnKeyPressed(
                event -> {
                    if(((KeyEvent)event).getCode() == KeyCode.ENTER){
                        ((Button)self.getDialogPane().lookupButton(ButtonType.OK)).fire();
                    }
                });

        this.getDialogPane().lookupButton(ButtonType.CANCEL).setOnKeyPressed(
                event -> {
                    if(((KeyEvent)event).getCode() == KeyCode.ENTER){
                        ((Button)self.getDialogPane().lookupButton(ButtonType.CANCEL)).fire();
                    }
                });

        Platform.runLater(directoryButton::requestFocus);
        this.setResultConverter((ButtonType button) -> {
            if (button == ButtonType.OK) {
                return textField.getText();
            }
            return null;
        });
        this.optionalResult = this.showAndWait();
    }
}
