package com.thrifty.rent.view.menu;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.model.Car;
import com.thrifty.rent.model.Van;
import com.thrifty.rent.model.Vehicle;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.util.DateTime;
import com.thrifty.rent.view.TaskDialog;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.StageStyle;
import javafx.util.StringConverter;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.thrifty.rent.controller.ApplicationContext.*;

public class NewVehicle extends TaskDialog {
    private final FileChooser fileChooser = new FileChooser();
    private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");
    private NewVehicle self;
    private ComboBox<String> vehicleTypes = new ComboBox<>();
    private ComboBox<Integer> year = new ComboBox<>();
    private com.thrifty.rent.view.control.TextField vehicleId = new com.thrifty.rent.view.control.TextField(50);
    private Label message = new Label("");
    private com.thrifty.rent.view.control.TextField make = new com.thrifty.rent.view.control.TextField(100);
    private com.thrifty.rent.view.control.TextField model = new com.thrifty.rent.view.control.TextField(100);
    private ComboBox<Integer> seats = new ComboBox<>();
    private DatePicker lastMaintenanceDate = new DatePicker();
    private ImageView imageView = new ImageView();
    private Button fileButton = new Button("...");
    private String imageFile = defaultImage;
    private VehicleTypes type;

    private String regex = "^[V|C]{1}[_]{1}[0-9 a-z A-Z]{1,}$";
    private Pattern pattern = Pattern.compile(regex);

    public NewVehicle(Callback c) {
        super(c);
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setText("Save");
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setDefaultButton(false);
        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText("Add Vehicle");
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        message.setStyle("-fx-font-weight: bold; -fx-text-fill: red;");
        self = this;
        this.initialize();
    }

    private void reset() {
        message.setVisible(false);
        message.setText("");
        vehicleTypes.pseudoClassStateChanged(errorClass, false);
        vehicleId.pseudoClassStateChanged(errorClass, false);
        year.pseudoClassStateChanged(errorClass, false);
        make.pseudoClassStateChanged(errorClass, false);
        model.pseudoClassStateChanged(errorClass, false);
        seats.pseudoClassStateChanged(errorClass, false);
        lastMaintenanceDate.pseudoClassStateChanged(errorClass, false);
    }

    private void setupOKButton() {
        self.getDialogPane().lookupButton(ButtonType.OK).addEventFilter(ActionEvent.ACTION,
                event -> {
                    reset();
                    List<String> errors = validate();
                    // Check whether some conditions are fulfilled
                    if (errors.size() > 0) {
                        // The conditions are not fulfilled so we consume the event
                        // to prevent the dialog to close
                        message.setVisible(true);
                        message.setText("Invalid " + String.join(", ", errors));
                        event.consume();
                    } else {
                        try {
                            Vehicle vehicle;
                            if (type == VehicleTypes.CAR) {
                                vehicle = new Car(vehicleId.getText(),
                                        year.getSelectionModel().getSelectedItem().shortValue(),
                                        make.getText(),
                                        model.getText(),
                                        seats.getSelectionModel().getSelectedItem().byteValue(),
                                        StatusTypes.AVAILABLE,
                                        imageFile
                                );
                            } else {
                                vehicle = new Van(vehicleId.getText(),
                                        year.getSelectionModel().getSelectedItem().shortValue(),
                                        make.getText(),
                                        model.getText(),
                                        StatusTypes.AVAILABLE,
                                        new DateTime(lastMaintenanceDate.getValue()),
                                        imageFile);
                            }
                            c.execute(vehicle);
                        } catch (CallExecutionException e) {
                            message.setVisible(true);
                            message.setText(e.getMessage());
                            event.consume();
                        }
                    }
                }
        );
    }

    private List<String> validate() {
        List<String> errors = new ArrayList<>();
        type = null;
        if (null == vehicleTypes.getSelectionModel().getSelectedItem()) {
            vehicleTypes.pseudoClassStateChanged(errorClass, true);
            errors.add("Vehicle type");
        } else
            type = vehicleTypes.getSelectionModel().getSelectedItem().equalsIgnoreCase("CAR") ? VehicleTypes.CAR : VehicleTypes.VAN;

        if (null == vehicleId.getText() || "".equals(vehicleId.getText().trim())
                || vehicleId.getText().trim().length() < 3) {
            vehicleId.pseudoClassStateChanged(errorClass, true);
            errors.add("Vehicle Id");
        } else if (null != vehicleId.getText()) {
            Matcher matcher = pattern.matcher(vehicleId.getText());
            if (!matcher.matches()) {
                vehicleId.pseudoClassStateChanged(errorClass, true);
                errors.add("Vehicle Id");
            } else if (null != type && null != vehicleId.getText() &&
                    !((type == VehicleTypes.VAN && vehicleId.getText().startsWith("V_"))
                            || (type == VehicleTypes.CAR && vehicleId.getText().startsWith("C_")))) {
                vehicleId.pseudoClassStateChanged(errorClass, true);
                errors.add("Vehicle Id");
            }
        }
        if (null == year.getSelectionModel().getSelectedItem()) {
            year.pseudoClassStateChanged(errorClass, true);
            errors.add("Year");
        }
        if (null == make.getText() || "".equals(make.getText().trim())) {
            make.pseudoClassStateChanged(errorClass, true);
            errors.add("Make");
        }
        if (null == model.getText() || "".equals(model.getText().trim())) {
            model.pseudoClassStateChanged(errorClass, true);
            errors.add("Model");
        }
        if (!seats.isDisabled() && null == seats.getSelectionModel().getSelectedItem()) {
            seats.pseudoClassStateChanged(errorClass, true);
            errors.add("Seats");
        }
        if (!lastMaintenanceDate.isDisabled() && (null == lastMaintenanceDate.getValue()
                || lastMaintenanceDate.getValue().isAfter(LocalDate.now()))) {
            lastMaintenanceDate.pseudoClassStateChanged(errorClass, true);
            errors.add("Date");
        }
        return errors;
    }

    private void initialize() {
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("jpeg", "*.jpg", "png", "*.png"));
        imageView.setImage(new Image(
                        getClass().getResourceAsStream("/com/thrifty/rent/view/resources/na.jpg"), imageWidth, imageHeight, false, false)
        );
        initializeLastMaintenanceDate();
        this.getDialogPane().setContent(new VBox(12, initializeControls(), message));
        this.getDialogPane().lookupButton(ButtonType.OK).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.OK)).fire();
        });
        this.getDialogPane().lookupButton(ButtonType.CANCEL).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.CANCEL)).fire();
        });
        this.getDialogPane().getScene().focusOwnerProperty().addListener(
                (prop, oldNode, newNode) -> self.reset());
        seats.setDisable(true);
        lastMaintenanceDate.setDisable(true);
        vehicleTypes.setOnAction((e) -> {
            seats.setDisable(true);
            lastMaintenanceDate.setDisable(true);
            seats.pseudoClassStateChanged(errorClass, false);
            lastMaintenanceDate.pseudoClassStateChanged(errorClass, false);
            String item = vehicleTypes.getSelectionModel().getSelectedItem();
            if (null != item) {
                if (item.equals("VAN")) {
                    lastMaintenanceDate.setDisable(false);
                    seats.getSelectionModel().clearSelection();
                } else seats.setDisable(false);
            }
        });
        fileButton.setOnAction(actionEvent -> {
            File file = fileChooser.showOpenDialog(self.getDialogPane().getScene().getWindow());
            if (file != null) {
                imageFile = file.getAbsolutePath();
                imageView.setImage(new Image(
                                file.toURI().toString(), imageWidth, imageHeight, false, false)
                );
            }
        });
        fileButton.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                fileButton.fire();
        });
        setupOKButton();
        Platform.runLater(vehicleTypes::requestFocus);
        message.setVisible(false);
        this.setResultConverter((ButtonType button) -> (button == ButtonType.OK) ? true : null);
        this.optionalResult = this.showAndWait();
    }

    private void initializeLastMaintenanceDate() {
        lastMaintenanceDate.setConverter(new StringConverter<LocalDate>() {
            String pattern = "dd/MM/yyyy";
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

            {
                lastMaintenanceDate.setPromptText(pattern.toLowerCase());
            }

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });
        LocalDate minDate = LocalDate.of(2000, 1, 1);
        LocalDate maxDate = LocalDate.now();
        lastMaintenanceDate.setDayCellFactory(d -> new DateCell() {
            @Override
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                setDisable(item.isAfter(maxDate) || item.isBefore(minDate));
            }
        });
    }

    private GridPane initializeControls() {
        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(12);
        ColumnConstraints left = new ColumnConstraints();
        left.setHalignment(HPos.LEFT);
        pane.getColumnConstraints().add(left);
        ColumnConstraints right = new ColumnConstraints();
        right.setHalignment(HPos.RIGHT);
        pane.getColumnConstraints().add(right);

        Label labelVehicleType = new Label("Vehicle Type");
        vehicleTypes.getItems().addAll("CAR", "VAN");
        pane.add(labelVehicleType, 0, 0);
        pane.add(vehicleTypes, 1, 0);

        Label labelVehicleId = new Label("Vehicle Id");
        pane.add(labelVehicleId, 0, 1);
        pane.add(vehicleId, 1, 1);

        Label labelYear = new Label("Year");
        for (int i = Calendar.getInstance().get(Calendar.YEAR); i > 1929; i--)
            year.getItems().add(i);
        pane.add(labelYear, 0, 2);
        pane.add(year, 1, 2);

        Label labelMake = new Label("Make");
        pane.add(labelMake, 0, 3);
        pane.add(make, 1, 3);

        Label labelModel = new Label("Model");
        pane.add(labelModel, 0, 4);
        pane.add(model, 1, 4);

        Label labelSeats = new Label("Number of Seats");
        seats.getItems().addAll(4, 7);
        pane.add(labelSeats, 0, 5);
        pane.add(seats, 1, 5);

        Label labelLastMaintenanceDate = new Label("Last Maintenance Date (dd/mm/yyyy)     ");
        pane.add(labelLastMaintenanceDate, 0, 6);
        pane.add(lastMaintenanceDate, 1, 6);

        Label labelImage = new Label("Image");
        pane.add(labelImage, 0, 7);
        HBox imageBox = new HBox(imageView, fileButton);
        imageBox.setSpacing(5);
        imageBox.setAlignment(Pos.CENTER_RIGHT);
        pane.add(imageBox, 1, 7);
        return pane;
    }
}
