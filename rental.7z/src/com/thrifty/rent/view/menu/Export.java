package com.thrifty.rent.view.menu;

import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.task.Callback;
import com.thrifty.rent.view.TaskDialog;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.StageStyle;

import java.io.File;

public class Export extends TaskDialog {

    private final DirectoryChooser directoryChooser = new DirectoryChooser();
    private final PseudoClass messageClass = PseudoClass.getPseudoClass("message");
    private Export self;
    private Label message = new Label("");
    private TextField textField = new TextField();

    public Export(Callback c) {
        super(c);
        directoryChooser.setTitle("Select directory for export");
        directoryChooser.setInitialDirectory(new File(System.getProperty("user.home")));
        this.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        this.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
        ((Button) this.getDialogPane().lookupButton(ButtonType.OK)).setDefaultButton(false);
        this.initStyle(StageStyle.UNDECORATED);
        this.setTitle(null);
        this.setHeaderText("Export Data");
        this.setGraphic(null);
        this.getDialogPane().getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        // Label label = new Label("Select the folder to export data ");
        self = this;
        message.setVisible(false);
        message.pseudoClassStateChanged(messageClass, true);
        setupOKButton();
        HBox hbox = new HBox();
        hbox.setSpacing(2.0);
        Button directoryButton = new Button("...");
        directoryButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                self.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
                File dir = directoryChooser.showDialog(self.getDialogPane().getScene().getWindow());
                if (dir != null) {
                    textField.setText(dir.getAbsolutePath());
                    self.getDialogPane().lookupButton(ButtonType.OK).setDisable(false);
                } else textField.setText(null);
            }
        });
        textField.setEditable(false);
        textField.setFocusTraversable(false);
        hbox.getChildren().add(textField);
        hbox.getChildren().add(directoryButton);
        this.getDialogPane().setContent(new VBox(12, message, hbox));
        directoryButton.setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                directoryButton.fire();
        });
        this.getDialogPane().lookupButton(ButtonType.OK).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.OK)).fire();
        });
        this.getDialogPane().lookupButton(ButtonType.CANCEL).setOnKeyPressed(event -> {
            if (((KeyEvent) event).getCode() == KeyCode.ENTER)
                ((Button) self.getDialogPane().lookupButton(ButtonType.CANCEL)).fire();
        });
        Platform.runLater(directoryButton::requestFocus);
        this.setResultConverter((ButtonType button) -> (button == ButtonType.OK) ? true : null);
        this.optionalResult = this.showAndWait();
    }

    private void setupOKButton() {
        self.getDialogPane().lookupButton(ButtonType.OK).addEventFilter(ActionEvent.ACTION,
                event -> {
                    message.setVisible(false);
                    message.setText("");
                    try {
                        c.execute(textField.getText());
                    } catch (CallExecutionException e) {
                        message.setVisible(true);
                        message.setText(e.getMessage());
                        event.consume();
                    }
                }
        );
    }
}
