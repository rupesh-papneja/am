package com.thrifty.rent.view.login;

import com.thrifty.rent.exception.CallExecutionException;
import com.thrifty.rent.task.Callback;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Login extends Stage {
    private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");
    private TextField textUser = new TextField();
    private PasswordField textPassword = new PasswordField();
    private Label message = new Label();
    private Button login = new Button();
    private Button cancel = new Button();
    private  Font font = new Font("System Bold",13.0);
    private Callback c;

    public Login(Callback c) {
        this.c = c;
        initStyle(StageStyle.UNDECORATED);
        getIcons().add(new Image(getClass().getResourceAsStream("/com/thrifty/rent/view/resources/icon.png")));
        AnchorPane pane = new AnchorPane();
        pane.getStylesheets().add(
                getClass().getResource("/com/thrifty/rent/view/resources/theme.css").toExternalForm());
        pane.setPrefHeight(260.0);
        pane.setPrefWidth(419.0);

        Label labelUser = new Label("User");
        labelUser.setLayoutX(25.0);
        labelUser.setLayoutY(42.0);
        labelUser.setFont(font);

        Label labelPassword = new Label("Password");
        labelPassword.setLayoutX(25.0);
        labelPassword.setLayoutY(115.0);
        labelPassword.setFont(font);

        initializeControls();
        initializeButtons();
        pane.getChildren().addAll(textUser, textPassword, message, login, cancel, labelUser, labelPassword);
        Scene scene = new Scene(pane);
        scene.focusOwnerProperty().addListener(
                (prop, oldNode, newNode) -> {
                    message.setText("");
                    textUser.pseudoClassStateChanged(errorClass, false);
                    textPassword.pseudoClassStateChanged(errorClass, false);
                }
        );
        setScene(scene);
        setTitle("Thrifty Rental System");
        show();
    }

    private void initializeControls() {
        message.setLayoutX(25.0);
        message.setLayoutY(160.0);
        textUser.setLayoutX(95.0);
        textUser.setLayoutY(35.0);
        textUser.setPrefHeight(33.0);
        textUser.setPrefWidth(259.0);
        textPassword.setLayoutX(95.0);
        textPassword.setLayoutY(105.0);
        textPassword.setPrefHeight(33.0);
        textPassword.setPrefWidth(259.0);
        message.setStyle("-fx-font-weight: bold; -fx-text-fill: rgba(9, 172, 242, 255);");
    }

    private boolean validate() {
        message.setText("");
        textUser.pseudoClassStateChanged(errorClass, false);
        textPassword.pseudoClassStateChanged(errorClass, false);
        String email = textUser.getText().toString();
        String password = textPassword.getText().toString();
        if (null == email || email.trim().length() == 0) {
            message.setText("Please enter user name.");
            textUser.pseudoClassStateChanged(errorClass, true);
            return false;
        }
        if (null == password || password.trim().length() == 0) {
            message.setText("Please enter password.");
            textPassword.pseudoClassStateChanged(errorClass, true);
            return false;
        }
        if (!"root".equals(password) || !"root".equals(password)) {
            message.setText("Invalid user name or password.");
            textUser.pseudoClassStateChanged(errorClass, true);
            textPassword.pseudoClassStateChanged(errorClass, true);
            return false;
        }
        return true;
    }

    private void initializeButtons() {
        login.setLayoutX(106.0);
        login.setLayoutY(200.0);
        login.setOnKeyPressed(keyEvent -> {
            if (((KeyEvent) keyEvent).getCode() == KeyCode.ENTER) {
                Object s = keyEvent.getSource();
                if (s instanceof Button) {
                    Button button = (Button) s;
                    button.fire();
                }
            }
        });
        login.setPrefHeight(40.0);
        login.setPrefWidth(90.0);
        login.setMnemonicParsing(false);
        login.setText("Login");
        login.setOnAction(actionEvent -> {
            if(validate()) {
                try {
                    c.execute(Boolean.TRUE);
                } catch (CallExecutionException e) {
                    actionEvent.consume();
                }
            }
        });
        cancel.setLayoutX(250.0);
        cancel.setLayoutY(200.0);
        cancel.setOnKeyPressed(keyEvent -> {
            if (((KeyEvent) keyEvent).getCode() == KeyCode.ENTER) {
                Object s = keyEvent.getSource();
                if (s instanceof Button) {
                    Button button = (Button) s;
                    button.fire();
                }
            }
        });
        cancel.setPrefHeight(40.0);
        cancel.setPrefWidth(90.0);
        cancel.setMnemonicParsing(false);
        cancel.setText("Cancel");
        cancel.setOnAction(actionEvent -> {
            System.exit(0);
        });

        cancel.setFont(font);
        login.setFont(font);
    }
}
