package com.thrifty.rent.view.control;

import java.awt.*;

public class TextField extends javafx.scene.control.TextField {
    private int length;
    private int compare;

    public TextField(int length) {
        super();
        this.length = length;
    }

    public void replaceText(int start, int end, String text) {
        compare = getText().length() - (end - start) + text.length();
        if (compare <= length || start != end) {
            super.replaceText(start, end, text);
        } else {
            Toolkit.getDefaultToolkit().beep();
        }
    }

    public void replaceSelection(String text) {
        compare = getText().length() + text.length();
        if (compare <= length) {
            super.replaceSelection(text);
        } else {
            Toolkit.getDefaultToolkit().beep();
        }
    }
}
