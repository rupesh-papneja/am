package com.thrifty.rent.model;

import com.thrifty.rent.util.DateTime;

import java.text.DecimalFormat;

/**
 * Domain class representing rental record
 * @author Priya Narayan Dhingra
 * @version 1.0
 */
public class RentalRecord {

    private String recordId;
    private DateTime rentDate;
    private DateTime estimatedReturnDate;
    private DateTime actualReturnDate;
    private Double rentalFee;
    private Double lateFee;
    private DecimalFormat df = new DecimalFormat("#.00");

    public RentalRecord(String recordId, DateTime rentDate, DateTime estimatedReturnDate) {
        this.recordId = recordId;
        this.rentDate = rentDate;
        this.estimatedReturnDate = estimatedReturnDate;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(recordId);
        builder.append(':');
        builder.append(rentDate.toString());
        builder.append(':');
        builder.append(estimatedReturnDate.toString());
        builder.append(':');
        builder.append(actualReturnDate != null ? actualReturnDate.toString() : "none");
        builder.append(':');
        builder.append(rentalFee != null ? df.format(rentalFee) : "none");
        builder.append(':');
        builder.append(lateFee != null ? df.format(lateFee) : "none");
        return builder.toString();
    }

    public String getDetails() {
        StringBuilder builder = new StringBuilder();
        builder.append("\nRecord ID:             ");
        builder.append(recordId);
        builder.append("\nRent Date:             ");
        builder.append(rentDate.toString());
        builder.append("\nEstimated Return Date: ");
        builder.append(estimatedReturnDate.toString());
        if (actualReturnDate != null) {
            builder.append("\nActual Return Date:    ");
            builder.append(actualReturnDate.toString());
            builder.append("\nRental Fee:            ");
            builder.append(df.format(rentalFee));
            builder.append("\nLate Fee:              ");
            builder.append(df.format(lateFee != null ? lateFee : 0d));
        }
        return builder.toString();

    }

    void setActualReturnDate(DateTime actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }

    void setLateFee(Double lateFee) {
        this.lateFee = lateFee;
    }

    void setRentalFee(Double rentalFee) {
        this.rentalFee = rentalFee;
    }

    DateTime getEstimatedReturnDate(){
        return estimatedReturnDate;
    }

    DateTime getRentDate() {
        return rentDate;
    }
}
