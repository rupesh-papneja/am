package com.thrifty.rent.model;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.util.DateTime;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Created by Priya Dhingra on 30/03/2019.
 */
public class Car extends Vehicle {

    private static double RENTAL_RATE_4 = 78d;
    private static double RENTAL_RATE_7 = 113d;
    private static double LATE_RATE = 1.25d;

    public Car(String vehicleId, short year, String make, String model, byte numOfSeats, StatusTypes status,
               String imageFile) {
        super(vehicleId, year, make, model, numOfSeats, VehicleTypes.CAR, status, null, imageFile);
    }

    @Override
    public boolean rent(String customerId, DateTime rentDate, int numOfRentDay) {
        String[] errors = validate(rentDate, numOfRentDay);
        if (errors.length > 0) {
            for (String error : errors) {
                System.out.println(error);
            }
            return false;
        }
        setStatus(StatusTypes.RENTED);
        String recordId = getVehicleId() + '_' + customerId + '_' + rentDate.getEightDigitDate();
        DateTime estimatedReturnDate = new DateTime(rentDate, numOfRentDay);
        RentalRecord rentalRecord = new RentalRecord(recordId, rentDate, estimatedReturnDate);
        setRentalRecord(rentalRecord);
        return true;
    }

    private String[] validate(DateTime rentDate, int numOfRentDay) {
        List<String> errors = new ArrayList<>();
        if (getStatus() != StatusTypes.AVAILABLE) {
            errors.add("\nVehicle not available for Renting.");
        }
        if (numOfRentDay < 1) {
            errors.add("\nA car can be rented for a minimum of 1 day.");
        }
        if (numOfRentDay > 14) {
            errors.add("\nA car can be rented for a maximum of 14 days.");
        }
        String dayName = rentDate.getNameOfDay();
        int minimumDays = 2;
        if (dayName.equalsIgnoreCase("Friday") || dayName.equalsIgnoreCase("Saturday")) {
            minimumDays = 3;
        }
        if (numOfRentDay < minimumDays) {
            errors.add("\nThe vehicle has to be rented for " + minimumDays + " days, when rental start day is " + dayName);
        }
        Calendar c = new GregorianCalendar();
        DateTime currentDate = new DateTime(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
        if (DateTime.diffDays(rentDate, currentDate) < 0) {
            errors.add("\nThe vehicle cannot be rented with the past date.");
        }
        return errors.toArray(new String[errors.size()]);
    }

    @Override
    public boolean returnVehicle(DateTime returnDate) {
        String[] errors = validateReturn(returnDate);
        if (errors.length > 0) {
            for (String error : errors) {
                System.out.println(error);
            }
            return false;
        }
        RentalRecord record = getRentalRecord();
        setStatus(StatusTypes.AVAILABLE);
        record.setActualReturnDate(returnDate);
        int diff = DateTime.diffDays(record.getEstimatedReturnDate(), returnDate);
        record.setRentalFee(DateTime.diffDays(record.getEstimatedReturnDate(), record.getRentDate())
                * (getNumOfSeats() == 4 ? RENTAL_RATE_4 : RENTAL_RATE_7));
        if (diff < 0) {
            record.setLateFee(-1 * diff * (getNumOfSeats() == 4 ? RENTAL_RATE_4 : RENTAL_RATE_7) * LATE_RATE);
        }
        return true;
    }

}
