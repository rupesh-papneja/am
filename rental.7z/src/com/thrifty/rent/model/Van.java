package com.thrifty.rent.model;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.util.DateTime;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Created by Priya Dhingra on 30/03/2019.
 */
public class Van extends Vehicle {

    private static double RENTAL_RATE = 235d;
    private static double LATE_FEE_RATE = 299d;

    public Van(String vehicleId, short year, String make, String model, StatusTypes status, DateTime lastMaintenanceDate,
               String imageFile) {
        super(vehicleId, year, make, model, (byte) 15, VehicleTypes.VAN, status, lastMaintenanceDate, imageFile);
    }

    @Override
    public boolean rent(String customerId, DateTime rentDate, int numOfRentDay) {
        String[] errors = validate(rentDate, numOfRentDay);
        if (errors.length > 0) {
            for (String error : errors) {
                System.out.println(error);
            }
            return false;
        }
        setStatus(StatusTypes.RENTED);
        String recordId = getVehicleId() + '_' + customerId + '_' + rentDate.getEightDigitDate();
        DateTime estimatedReturnDate = new DateTime(rentDate, numOfRentDay);
        RentalRecord rentalRecord = new RentalRecord(recordId, rentDate, estimatedReturnDate);
        // setRentalRecord(rentalRecord);
        return true;
    }

    private String[] validate(DateTime rentDate, int numOfRentDay) {
        List<String> errors = new ArrayList<>();
        if (getStatus() != StatusTypes.AVAILABLE) {
            errors.add("\nVehicle not available for Renting.");
        }
        if (numOfRentDay < 1) {
            errors.add("\nA van can be rented for a minimum of 1 day.");
        }
        Calendar c = new GregorianCalendar();
        DateTime currentDate = new DateTime(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
        if (DateTime.diffDays(currentDate, getLastMaintenanceDate()) >= 12) {
            errors.add("\nThe vehicle maintenance interval of 12 days has exceeded, cannot be rented.");
        }
        if (DateTime.diffDays(rentDate, currentDate) < 0) {
            errors.add("\nThe vehicle cannot be rented with the past date.");
        }
        return errors.toArray(new String[errors.size()]);
    }

    @Override
    public boolean returnVehicle(DateTime returnDate) {
        String[] errors = validateReturn(returnDate);
        if (errors.length > 0) {
            for (String error : errors) {
                System.out.println(error);
            }
            return false;
        }
        //RentalRecord record = getRentalRecord();
        setStatus(StatusTypes.AVAILABLE);
        /* record.setActualReturnDate(returnDate);
        int diff = DateTime.diffDays(record.getEstimatedReturnDate(), returnDate);
        record.setRentalFee(DateTime.diffDays(record.getEstimatedReturnDate(), record.getRentDate()) * RENTAL_RATE);
        if (diff < 0) {
            record.setLateFee(-1 * diff * LATE_FEE_RATE);
        }*/
        return true;
    }
}
