package com.thrifty.rent.model;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.exception.MaintenanceCompletionException;
import com.thrifty.rent.exception.MaintenanceException;
import com.thrifty.rent.exception.RentException;
import com.thrifty.rent.exception.ReturnException;
import com.thrifty.rent.util.DateTime;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Domain class representing Vehicle
 *
 * @author Priya Narayan Dhingra
 * @version 1.0
 */
public abstract class Vehicle implements Serializable {
    private String imageFile;
    private String vehicleId;
    private short year;
    private String make;
    private String model;
    private byte numOfSeats;
    private VehicleTypes type;
    private StatusTypes status;
    private DateTime lastMaintenanceDate;

    protected Vehicle(String vehicleId, short year, String make, String model, byte numOfSeats, VehicleTypes type,
                      StatusTypes status, DateTime lastMaintenanceDate, String imageFile) {
        this.vehicleId = vehicleId;
        this.year = year;
        this.make = make;
        this.model = model;
        this.numOfSeats = numOfSeats;
        this.type = type;
        this.status = status;
        this.lastMaintenanceDate = lastMaintenanceDate;
        this.imageFile = imageFile;
    }

    @Override
    public String toString() {
        return vehicleId + ':' + year + ':' + make + ':' + model + ':' + numOfSeats + ':' + status + ':' + imageFile;
    }

    /**
     * Return the vehicle vehicleId
     *
     * @return String vehicleId
     */
    public String getVehicleId() {
        return vehicleId;
    }

    public VehicleTypes getType() {
        return type;
    }

    public StatusTypes getStatus() {
        return status;
    }

    public void setStatus(StatusTypes status) {
        this.status = status;
    }

    public DateTime getLastMaintenanceDate() {
        return lastMaintenanceDate;
    }

    public byte getNumOfSeats() {
        return numOfSeats;
    }

    public String getImageFile() {
        return imageFile;
    }

    public short getYear() {
        return year;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getDetails() {
        StringBuilder builder = new StringBuilder();
        builder.append("\nVehicle ID:            ");
        builder.append(vehicleId);
        builder.append("\nYear:                  ");
        builder.append(year);
        builder.append("\nMake:                  ");
        builder.append(make);
        builder.append("\nNumber of seats:       ");
        builder.append(numOfSeats);
        builder.append("\nStatus:                ");
        builder.append(status.toString());
        if (lastMaintenanceDate != null) {
            builder.append("\nLast maintenance date: ");
            builder.append(lastMaintenanceDate.toString());
        }
        builder.append("\nImage:                ");
        builder.append(imageFile);
        return builder.toString();
    }

    public abstract RentalRecord rent(String customerId, DateTime rentDate, int numOfRentDay) throws RentException;

    public abstract void returnVehicle(DateTime returnDate, RentalRecord record) throws ReturnException;

    public void performMaintenance() throws MaintenanceException {
        if (status == StatusTypes.AVAILABLE) {
            status = StatusTypes.MAINTENANCE;
        } else throw new MaintenanceException("The vehicle is not available for maintenance.");
    }

    public void completeMaintenance(DateTime completionDate) throws MaintenanceCompletionException {
        if (status == StatusTypes.MAINTENANCE) {
            lastMaintenanceDate = completionDate;
            status = StatusTypes.AVAILABLE;
        } else throw new MaintenanceCompletionException("The vehicle is not under maintenance.");
    }

    protected String[] validateReturn(DateTime returnDate, RentalRecord record) {
        List<String> errors = new ArrayList<>();
        if (getStatus() != StatusTypes.RENTED) {
            errors.add("\nVehicle is not Rented.");
        }

        if (DateTime.diffDays(returnDate, record.getRentDate()) < 0) {
            errors.add("\nThe return date cannot be less than rental start date.");
        }
        return errors.toArray(new String[errors.size()]);
    }
}
