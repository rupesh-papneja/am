package com.thrifty.rent.model;

import java.io.Serializable;
import java.time.LocalDate;

public class RentSelectionModel implements Serializable {
    final LocalDate rentStartDate;
    final private String customerId;
    final private int numberOfDays;

    public RentSelectionModel(String customerId, int numberOfDays, LocalDate rentStartDate) {
        this.customerId = customerId;
        this.numberOfDays = numberOfDays;
        this.rentStartDate = rentStartDate;
    }

    public String getCustomerId() {
        return customerId;
    }

    public int getNumberOfDays() {
        return numberOfDays;
    }

    public LocalDate getRentStartDate() {
        return rentStartDate;
    }
}
