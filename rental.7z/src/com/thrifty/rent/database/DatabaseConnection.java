package com.thrifty.rent.database;

import java.sql.*;

public class DatabaseConnection {

    public Connection getConnection() {
        return connection;
    }

    private Connection connection = null;

    private static DatabaseConnection INSTANCE;
    private DatabaseConnection() {
    }

    public static DatabaseConnection instance() {
        if (null == INSTANCE) {
            INSTANCE = new DatabaseConnection();
        }
        return INSTANCE;
    }

    public void setup() {
        try {
            //Registering the HSQLDB JDBC driver
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
            //Creating the connection with HSQLDB
            connection = DriverManager.getConnection("jdbc:hsqldb:file:hsqldb/rental", "SA", "");
            if (connection == null){
                throw new Exception("Unable to setup database connection");
            }
            checkAndCreateTables();
        } catch (ClassNotFoundException|SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void checkAndCreateTables() throws SQLException{
        boolean vehicles = false;
        boolean rentalRecords = false;
        try (ResultSet rs = connection.createStatement().executeQuery("SELECT  TABLE_NAME FROM INFORMATION_SCHEMA.TABLES")) {

            while (rs.next()) {
                String catalogs = rs.getString(1);

                if ("VEHICLES".equals(catalogs)) {
                    vehicles = true;
                }
                if ("RENTAL_RECORDS".equals(catalogs)) {
                    rentalRecords = true;
                }
            }
            if (!vehicles) {
                Statement stmt = connection.createStatement();
                stmt.executeUpdate("CREATE TABLE VEHICLES (" +
                        "vehicleId VARCHAR(240) NOT NULL, " +
                        "year INT NOT NULL," +
                        "make VARCHAR(100) NOT NULL, " +
                        "model VARCHAR(100) NOT NULL, " +
                        "numOfSeats INT NOT NULL, " +
                        "type VARCHAR(6) NOT NULL, " +
                        "status VARCHAR(20) NOT NULL, " +
                        "lastMaintenanceDate DATE,PRIMARY KEY (vehicleId)" +
                        ");");
            }
            if(!rentalRecords) {
                Statement stmt = connection.createStatement();
                stmt.executeUpdate("CREATE TABLE RENTAL_RECORDS (" +
                        "recordId VARCHAR(240) NOT NULL, " +
                        "vehicleId VARCHAR(240) NOT NULL, " +
                        "rentDate DATE NOT NULL," +
                        "estimatedReturnDate DATE NOT NULL, " +
                        "actualReturnDate DATE," +
                        "rentalFee DECIMAL," +
                        "lateFee DECIMAL,"+
                        "PRIMARY KEY (recordId)," +
                        "FOREIGN KEY (vehicleId) REFERENCES VEHICLES(vehicleId)" +
                        ");");
            }
        }
    }

}
