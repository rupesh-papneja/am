package com.thrifty.rent.database;

import java.sql.*;

public class DatabaseConnection {

    private static DatabaseConnection INSTANCE;
    private Connection connection = null;

    private DatabaseConnection() {
    }

    public static DatabaseConnection instance() {
        if (null == INSTANCE) {
            INSTANCE = new DatabaseConnection();
        }
        return INSTANCE;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setup() {
        try {
            //Registering the HSQLDB JDBC driver
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
            //Creating the connection with HSQLDB
            connection = DriverManager.getConnection("jdbc:hsqldb:file:database/rental", "SA", "");
            if (connection == null) {
                throw new Exception("Unable to setup database connection");
            }
            checkAndCreateTables();
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void checkAndCreateTables() throws SQLException {
        boolean vehicles = false;
        boolean rentalRecords = false;
        try (ResultSet rs = connection.createStatement().executeQuery("SELECT  TABLE_NAME FROM INFORMATION_SCHEMA.TABLES")) {

            while (rs.next()) {
                String catalogs = rs.getString(1);

                if ("VEHICLES".equals(catalogs)) {
                    vehicles = true;
                }
                if ("RENTAL_RECORDS".equals(catalogs)) {
                    rentalRecords = true;
                }
            }
            if (!vehicles) {
                Statement stmt = connection.createStatement();
                stmt.executeUpdate("CREATE TABLE VEHICLES (" +
                        "ID VARCHAR(240) NOT NULL, " +
                        "YEAR INT NOT NULL," +
                        "MAKE VARCHAR(100) NOT NULL, " +
                        "MODEL VARCHAR(100) NOT NULL, " +
                        "SEATS INT NOT NULL, " +
                        "TYPE VARCHAR(6) NOT NULL, " +
                        "STATUS VARCHAR(20) NOT NULL, " +
                        "IMAGE VARCHAR(240) NOT NULL, " +
                        "LAST_MAINTENANCE_DATE DATE,PRIMARY KEY (ID)" +
                        ");");
            }
            if (!rentalRecords) {
                Statement stmt = connection.createStatement();
                stmt.executeUpdate("CREATE TABLE RENTAL_RECORDS (" +
                        "ID VARCHAR(240) NOT NULL, " +
                        "VEHICLE_ID VARCHAR(240) NOT NULL, " +
                        "RENT_DATE DATE NOT NULL," +
                        "ESTIMATED_RETURN_DATE DATE NOT NULL, " +
                        "ACTUAL_RETURN_DATE DATE," +
                        "RENTAL_FEE DECIMAL," +
                        "LATE_FEE DECIMAL," +
                        "UPDATED_AT TIMESTAMP NOT NULL," +
                        "PRIMARY KEY (ID)," +
                        "FOREIGN KEY (VEHICLE_ID) REFERENCES VEHICLES(ID)" +
                        ");");
            }
            connection.createStatement().executeUpdate("SET FILES WRITE DELAY FALSE");
        }
    }

}
