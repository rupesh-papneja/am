package com.thrifty.rent.database;

import com.thrifty.rent.enumerations.StatusTypes;
import com.thrifty.rent.enumerations.VehicleTypes;
import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.model.Car;
import com.thrifty.rent.model.Van;
import com.thrifty.rent.util.DateTime;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Vehicle {
    public void create(com.thrifty.rent.model.Vehicle vehicle) throws DatabaseException {
        try (PreparedStatement statement = DatabaseConnection.instance().getConnection().prepareStatement(
                "INSERT INTO VEHICLES(" +
                        "ID, " +
                        "YEAR," +
                        "MAKE, " +
                        "MODEL, " +
                        "SEATS, " +
                        "TYPE, " +
                        "STATUS, " +
                        "IMAGE, " +
                        "LAST_MAINTENANCE_DATE" +
                        ") VALUES (?, ?, ?, ?, ?, ?, ?, ? ,?)"
        )) {

            statement.setString(1, vehicle.getVehicleId());
            statement.setShort(2, vehicle.getYear());
            statement.setString(3, vehicle.getMake());
            statement.setString(4, vehicle.getModel());
            statement.setByte(5, vehicle.getNumOfSeats());
            statement.setString(6, vehicle.getType().toString());
            statement.setString(7, vehicle.getStatus().toString());
            statement.setString(8, vehicle.getImageFile());
            if (null != vehicle.getLastMaintenanceDate()) {
                statement.setDate(9, Date.valueOf(vehicle.getLastMaintenanceDate().getLocalDate()));
            } else statement.setNull(9, Types.DATE);
            statement.execute();
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public List<com.thrifty.rent.model.Vehicle> fetchAll() throws DatabaseException {
        List<com.thrifty.rent.model.Vehicle> vehicles;
        try (ResultSet rs = DatabaseConnection.instance().getConnection().createStatement().executeQuery("SELECT * FROM VEHICLES")) {
            vehicles = processRecords(rs);
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
        return vehicles;
    }

    public void checkNotExistsById(String vehicleId) throws DatabaseException {
        try (ResultSet rs = DatabaseConnection.instance().getConnection().createStatement().executeQuery(
                "SELECT * FROM VEHICLES WHERE ID = '" + vehicleId + "'"
        )) {
            if (rs.next()) {
                throw new DatabaseException("Vehicle already exits");
            }
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public List<String> fetchAllMakes() throws DatabaseException {
        List<String> makes = new ArrayList<>();
        try (ResultSet rs = DatabaseConnection.instance().getConnection().createStatement().executeQuery(
                "SELECT DISTINCT MAKE FROM VEHICLES order by MAKE ASC"
        )) {
            while (rs.next()) {
                makes.add(rs.getString(1));
            }
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
        return makes;
    }

    public List<com.thrifty.rent.model.Vehicle> filter(VehicleTypes vType, String make, StatusTypes statusTypes, Byte seats) throws DatabaseException {
        List<com.thrifty.rent.model.Vehicle> vehicles;
        StringBuilder query = new StringBuilder("SELECT * FROM VEHICLES WHERE ");
        boolean useAnd = false;
        if (null != vType) {
            if (useAnd) {
                query.append(" AND ");
            }
            query.append(" TYPE = '");
            query.append(vType.toString());
            query.append('\'');
            useAnd = true;
        }
        if (null != make) {
            if (useAnd) {
                query.append(" AND ");
            }
            query.append(" MAKE = '");
            query.append(make);
            query.append('\'');
            useAnd = true;
        }
        if (null != statusTypes) {
            if (useAnd) {
                query.append(" AND ");
            }
            query.append(" STATUS = '");
            query.append(statusTypes.toString());
            query.append('\'');
            useAnd = true;
        }
        if (null != seats) {
            if (useAnd) {
                query.append(" AND ");
            }
            query.append(" SEATS = ");
            query.append(seats);
        }

        try (ResultSet rs = DatabaseConnection.instance().getConnection().createStatement().executeQuery(query.toString())) {
            vehicles = processRecords(rs);
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
        return vehicles;
    }

    private List<com.thrifty.rent.model.Vehicle> processRecords(ResultSet rs) throws SQLException {
        List<com.thrifty.rent.model.Vehicle> vehicles = new ArrayList<>();
        while (rs.next()) {
            String t = rs.getString("TYPE");
            VehicleTypes type = VehicleTypes.valueOf(t.toUpperCase());
            com.thrifty.rent.model.Vehicle vehicle;
            if (type == VehicleTypes.CAR) {
                vehicle = new Car(rs.getString("ID"),
                        rs.getShort("YEAR"),
                        rs.getString("MAKE"),
                        rs.getString("MODEL"),
                        rs.getByte("SEATS"),
                        StatusTypes.valueOf(rs.getString("STATUS").toUpperCase()),
                        rs.getString("IMAGE")
                );
            } else {
                vehicle = new Van(rs.getString("ID"),
                        rs.getShort("YEAR"),
                        rs.getString("MAKE"),
                        rs.getString("MODEL"),
                        StatusTypes.valueOf(rs.getString("STATUS").toUpperCase()),
                        new DateTime(rs.getDate("LAST_MAINTENANCE_DATE").toLocalDate()),
                        rs.getString("IMAGE")
                );
            }
            vehicles.add(vehicle);
        }
        return vehicles;
    }

    public com.thrifty.rent.model.Vehicle fetchById(String vehicleId) throws DatabaseException {
        List<com.thrifty.rent.model.Vehicle> vehicles;
        try (ResultSet rs = DatabaseConnection.instance().getConnection().createStatement().executeQuery(
                "SELECT * FROM VEHICLES WHERE ID = '" + vehicleId + "'"
        )) {
            vehicles = processRecords(rs);
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
        if (vehicles == null || vehicles.size() == 0)
            throw new DatabaseException("No records found");
        return vehicles.get(0);
    }

    public void updateStatus(String vehicleId, StatusTypes maintenance) throws DatabaseException {
        try (PreparedStatement statement = DatabaseConnection.instance().getConnection().prepareStatement(
                "UPDATE VEHICLES SET STATUS = ? WHERE ID = ?"
        )) {

            statement.setString(1, maintenance.toString());
            statement.setString(2, vehicleId);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public void updateStatusAndMaintenanceDate(String vehicleId, StatusTypes status, LocalDate maintenanceDate) throws DatabaseException {
        try (PreparedStatement statement = DatabaseConnection.instance().getConnection().prepareStatement(
                "UPDATE VEHICLES SET STATUS = ?, LAST_MAINTENANCE_DATE = ? WHERE ID = ?"
        )) {

            statement.setString(1, status.toString());
            statement.setDate(2, Date.valueOf(maintenanceDate));
            statement.setString(3, vehicleId);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }
}
