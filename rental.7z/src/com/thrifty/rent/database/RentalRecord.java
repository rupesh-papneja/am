package com.thrifty.rent.database;

import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.util.DateTime;

import java.sql.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class RentalRecord {
    public List<com.thrifty.rent.model.RentalRecord> fetchAll(String vehicleId) throws DatabaseException {
        List<com.thrifty.rent.model.RentalRecord> rentalRecords = new ArrayList<>();
        try (ResultSet rs = DatabaseConnection.instance().getConnection().createStatement().executeQuery(
                "SELECT * FROM RENTAL_RECORDS WHERE VEHICLE_ID = '" + vehicleId + "' order by UPDATED_AT DESC"
        )) {
            while (rs.next()) {
                com.thrifty.rent.model.RentalRecord record = new com.thrifty.rent.model.RentalRecord(
                        rs.getString("ID"),
                        new DateTime(rs.getDate("RENT_DATE").toLocalDate()),
                        new DateTime(rs.getDate("ESTIMATED_RETURN_DATE").toLocalDate())
                );
                record.setVehicleId(rs.getString("VEHICLE_ID"));
                if (null != rs.getDate("ACTUAL_RETURN_DATE")) {
                    record.setActualReturnDate(new DateTime(rs.getDate("ACTUAL_RETURN_DATE").toLocalDate()));
                }
                if (null != rs.getBigDecimal("RENTAL_FEE")) {
                    record.setRentalFee(rs.getBigDecimal("RENTAL_FEE").doubleValue());
                }
                if (null != rs.getBigDecimal("LATE_FEE")) {
                    record.setLateFee(rs.getBigDecimal("LATE_FEE").doubleValue());
                }
                rentalRecords.add(record);
            }
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
        return rentalRecords;
    }

    public void insert(com.thrifty.rent.model.RentalRecord record) throws DatabaseException {
        try (PreparedStatement statement = DatabaseConnection.instance().getConnection().prepareStatement(
                "INSERT INTO RENTAL_RECORDS(" +
                        "ID, " +
                        "RENT_DATE," +
                        "ESTIMATED_RETURN_DATE, " +
                        "VEHICLE_ID, " +
                        "UPDATED_AT " +
                        ") VALUES (?, ?, ?, ?, ?)"
        )) {

            statement.setString(1, record.getRecordId());
            statement.setDate(2, Date.valueOf(record.getRentDate().getLocalDate()));
            statement.setDate(3, Date.valueOf(record.getEstimatedReturnDate().getLocalDate()));
            statement.setString(4, record.getVehicleId());
            statement.setTimestamp(5, Timestamp.from(Instant.now()));
            statement.execute();
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public void update(com.thrifty.rent.model.RentalRecord record) throws DatabaseException {
        try (PreparedStatement statement = DatabaseConnection.instance().getConnection().prepareStatement(
                "UPDATE RENTAL_RECORDS SET ACTUAL_RETURN_DATE = ?, RENTAL_FEE = ?, LATE_FEE = ?, UPDATED_AT = ?" +
                        "  WHERE ID = ?"
        )) {

            statement.setDate(1, Date.valueOf(record.getActualReturnDate().getLocalDate()));
            statement.setDouble(2, record.getRentalFee());
            statement.setDouble(3, record.getLateFee());
            statement.setTimestamp(4, Timestamp.from(Instant.now()));
            statement.setString(5, record.getRecordId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }
}
