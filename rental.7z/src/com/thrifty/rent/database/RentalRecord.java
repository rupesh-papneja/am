package com.thrifty.rent.database;

import com.thrifty.rent.exception.DatabaseException;
import com.thrifty.rent.util.DateTime;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RentalRecord {
    public List<com.thrifty.rent.model.RentalRecord> fetchAll(String vehicleId) throws DatabaseException {
        List<com.thrifty.rent.model.RentalRecord> rentalRecords = new ArrayList<>();
        try (ResultSet rs = DatabaseConnection.instance().getConnection().createStatement().executeQuery(
                "SELECT * FROM RENTAL_RECORDS WHERE VEHICLE_ID = '" + vehicleId + "' order by UPDATED_AT DESC"
        )) {
            while (rs.next()) {
                com.thrifty.rent.model.RentalRecord record = new com.thrifty.rent.model.RentalRecord(
                        rs.getString("ID"),
                        new DateTime(rs.getDate("RENT_DATE").toLocalDate()),
                        new DateTime(rs.getDate("ESTIMATED_RETURN_DATE").toLocalDate())
                );
                record.setVehicleId(rs.getString("VEHICLE_ID"));
                if (null != rs.getDate("ACTUAL_RETURN_DATE")) {
                    record.setActualReturnDate(new DateTime(rs.getDate("ACTUAL_RETURN_DATE").toLocalDate()));
                }
                if (null != rs.getBigDecimal("RENTAL_FEE")) {
                    record.setRentalFee(rs.getBigDecimal("RENTAL_FEE").doubleValue());
                }
                if (null != rs.getBigDecimal("LATE_FEE")) {
                    record.setLateFee(rs.getBigDecimal("LATE_FEE").doubleValue());
                }
                rentalRecords.add(record);
            }
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
        return rentalRecords;
    }
}
