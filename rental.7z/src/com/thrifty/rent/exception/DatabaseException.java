package com.thrifty.rent.exception;

public class DatabaseException extends ApplicationException {
    public DatabaseException(String message) {
        super(message);
    }

    public DatabaseException(Throwable t) {
        super(t);
    }
}
