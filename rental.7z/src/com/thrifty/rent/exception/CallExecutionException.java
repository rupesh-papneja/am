package com.thrifty.rent.exception;

public class CallExecutionException extends ApplicationException {
    public CallExecutionException(String message) {
        super(message);
    }

    public CallExecutionException(Throwable t) {
        super(t);
    }
}
