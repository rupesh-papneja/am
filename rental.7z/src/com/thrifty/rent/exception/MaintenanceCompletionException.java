package com.thrifty.rent.exception;

public class MaintenanceCompletionException extends ApplicationException {
    public MaintenanceCompletionException(String message) {
        super(message);
    }

    public MaintenanceCompletionException(Throwable t) {
        super(t);
    }
}
