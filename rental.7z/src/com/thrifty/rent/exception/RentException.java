package com.thrifty.rent.exception;

public class RentException extends ApplicationException {
    public RentException(String message) {
        super(message);
    }

    public RentException(Throwable t) {
        super(t);
    }
}
