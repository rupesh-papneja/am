package com.thrifty.rent.exception;

public class MaintenanceException extends ApplicationException {
    public MaintenanceException(String message) {
        super(message);
    }

    public MaintenanceException(Throwable t) {
        super(t);
    }
}
