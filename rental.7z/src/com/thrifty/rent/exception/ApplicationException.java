package com.thrifty.rent.exception;

public class ApplicationException extends Exception {
    public ApplicationException(String message) {
        super(message);
    }

    public ApplicationException(Throwable t) {
        super(t);
    }
}
