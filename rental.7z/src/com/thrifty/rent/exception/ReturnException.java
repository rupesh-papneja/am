package com.thrifty.rent.exception;

public class ReturnException extends ApplicationException {
    public ReturnException(String message) {
        super(message);
    }

    public ReturnException(Throwable t) {
        super(t);
    }
}
